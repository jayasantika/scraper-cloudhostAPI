let fetch = require("node-fetch");

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Ex: ${usedPrefix}${command} Jiwa yang bersedih`;
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

    try {
        let response = await fetch(`https://api.betabotz.eu.org/api/search/lirik?lirik=${text}&apikey=${btc}`);
        let data = await response.json();

        if (!data.result || !data.result.lyrics) {
        	await conn.sendMessage(m.chat, { react: { text: `❌`, key: m.key }});
            return m.reply("Lagu tidak dapat ditemukan, silakan cari lagu yang lain");
        }

        let caption = `
${data.result.lyrics}

ℹ️ More info:
🔗 ${data.result.image}
🎤 Artist: ${data.result.artist}`;

        await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
        await conn.relayMessage(m.chat, {
            extendedTextMessage: {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: `🎵 ${data.result.title} - ${data.result.artist} 🎵`,
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: data.result.image,
                        sourceUrl: ''
                    }
                },
                mentions: [m.sender]
            }
        }, {});

    } catch (e) {
        console.log(e);
        await conn.sendMessage(m.chat, { react: { text: `❌`, key: m.key }});
        m.reply("Terjadi kesalahan, silakan coba lagi nanti");
    }
};

handler.help = ['lirik'].map(v => v + ' <Title>');
handler.tags = ['internet'];
handler.command = /^(lirik|lyrics|lyric)$/i;

module.exports = handler;