const moment = require('moment-timezone');
let handler = m => m;

handler.before = async function(m, { conn, isROwner, isPrems }) {
    if (m.chat.endsWith('broadcast')) return;
    if (m.fromMe) return;
    if (m.isGroup) return;

    let user = global.db.data.users[m.sender] || {}; // Pastikan objek user terdefinisi
    let username = conn.getName(m.sender) || 'Pengguna';

    // Periksa jika properti 'pc' ada dan belum lebih dari 24 jam
    if (user.pc && new Date() - user.pc < 86400000) return;

    let pesan = `Hai ${ucapan()} *${username.replace(/@.+/, '')}* 👋
${user.banned ? `Maaf, nomor kamu dibanned dan tidak bisa mengakses bot ini lagi!\n\n> *Jika ini adalah kesalahan, silakan hubungi owner: wa.me/${global.numberowner}*\n${global.wm}` 
: `Selamat datang di ${await conn.user.name}\n\n> *Silakan ketik .menu untuk melihat fitur bot ini!*\n\nCek channel bot ini untuk info selengkapnya tentang bot: https://whatsapp.com/channel/0029VaIEufDK0IBrsQWOCO3g\n\n*Web Musik:* https://musicplayer.jayawebstore.biz.id`}`;

    await conn.sendMessage(m.chat, {
        text: pesan,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                title: user.banned 
                    ? 'Sorry, Your Account Cannot Access This Bot!' 
                    : "I'm Nayaka. Ready To Help You!",
                body: global.wm,
                thumbnailUrl: 'https://pomf2.lain.la/f/7yu8083l.jpg',
                sourceUrl: global.channel, // Pastikan variabel 'channel' terdefinisi
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: null });

    user.pc = new Date().getTime(); // Simpan waktu terakhir pengiriman pesan
};

module.exports = handler;

function ucapan() {
    const hour_now = parseInt(moment.tz('Asia/Jakarta').format('HH'), 10);
    if (hour_now >= 3 && hour_now < 10) {
        return 'Selamat Pagi';
    } else if (hour_now >= 10 && hour_now < 15) {
        return 'Selamat Siang';
    } else if (hour_now >= 15 && hour_now < 17) {
        return 'Selamat Sore';
    } else if (hour_now >= 17 && hour_now < 18) {
        return 'Selamat Petang';
    } else {
        return 'Selamat Malam';
    }
}