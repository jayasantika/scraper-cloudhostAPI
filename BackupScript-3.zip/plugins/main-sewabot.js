let handler = async (m, { conn, command }) => {
    let txt = `*[ Chat Dengan Pemilik Bot ]*
wa.me/6289524664142

╔╣ *INVITE GRUP + PREMIUM* ( Reguler )
║ • Unlimited Limit
║ • 1 Bulan Masa Aktif Premium
║ • Full Akses Chat
║ • Garansi Sesuai Masa Aktif Grup
║ • Bebas Invite Ke 1 Grup Selama 1 Tahun
╚══╣ *Harga :* Rp.30.000

╔╣ *INVITE GRUP + PREMIUM* ( Pro )
║ • Unlimited Limit
║ • 1 Tahun Masa Aktif Premium
║ • Full Akses Chat
║ • Garansi Sesuai Masa Aktif Grup
║ • Bebas Invite Ke 1 Grup Permanen
╚══╣ *Harga :* Rp.50.000

╔╣ *SEWA BOT* ( Basic )
║ • Garansi 3 Hari Jika Bot Tidak Respon
║ • Bebas Invite ke 1 Grup
╚══╣ *Harga :* Rp.5.000 / minggu

╔╣ *SEWA BOT* ( Popular )
║ • Garansi 7 Hari Jika Bot Tidak Respon
║ • Bebas Invite ke 1 Grup
╚══╣ *Harga :* Rp.10.000 / bulan

- Pembayaran via *OVO / Dana / GoPay / Qris*

  *( Promo Panel Pterodactyl Unli 10k /Bulan )*
  
  Langsung Chat Dengan 6289524664142
- Whatsapp Multi Device
- Run via VPS (Always ON)`;

    try {
        await conn.relayMessage(m.chat, {
            requestPaymentMessage: {
                currencyCodeIso4217: 'IDR',
                amount1000: 25000 * 1000,
                requestFrom: '0@s.whatsapp.net',
                noteMessage: {
                    extendedTextMessage: {
                        text: txt,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            externalAdReply: {
                                showAdAttribution: false
                            }
                        }
                    }
                }
            }
        }, {});
    } catch (error) {
        console.error(error);
    }
};

handler.help = ['sewabot'];
handler.tags = ['main'];
handler.command = /^(sewa|sewabot)$/i;

module.exports = handler;