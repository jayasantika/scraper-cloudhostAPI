const { 
    BufferJSON, 
    WA_DEFAULT_EPHEMERAL, 
    generateWAMessageFromContent, 
    proto, 
    generateWAMessageContent, 
    generateWAMessage, 
    prepareWAMessageMedia, 
    areJidsSameUser, 
    getContentType 
} = require('@adiwajshing/baileys')

process.env.TZ = 'Asia/Jakarta'
let fs = require('fs')
let path = require('path')
let fetch = require('node-fetch')
let moment = require('moment-timezone')
let levelling = require('../lib/levelling')
let arrayMenu = [
  'all', 
  'ai', 
  'main', 
  'downloader', 
  'database',
  'rpg',
  'rpgG', 
  'sticker', 
  'advanced', 
  'xp', 
  'fun', 
  'game', 
  'github', 
  'group', 
  'image', 
  'nsfw', 
  'info', 
  'internet', 
  'islam', 
  'kerang', 
  'maker', 
  'news', 
  'owner', 
  'voice', 
  'quotes', 
  'store', 
  'stalk',
  'tools', 
  'anonymous',
  ''
  ];


const allTags = {
    'all': 'SEMUA MENU',
    'ai': 'MENU AI',
    'main': 'MENU UTAMA',
    'downloader': 'MENU DOWNLOADER',
    'database': 'MENU DATABASE',
    'rpg': 'MENU RPG',
    'rpgG': 'MENU RPG GUILD',
    'sticker': 'MENU CONVERT',
    'advanced': 'ADVANCED',
    'xp': 'MENU EXP',
    'fun': 'MENU FUN',
    'game': 'MENU GAME',
    'github': 'MENU GITHUB',
    'group': 'MENU GROUP',
    'image': 'MENU IMAGE',
    'nsfw': 'MENU NSFW',
    'info': 'MENU INFO',
    'internet': 'INTERNET',
    'islam': 'MENU ISLAMI',
    'kerang': 'MENU KERANG',
    'maker': 'MENU MAKER',
    'news': 'MENU NEWS',
    'owner': 'MENU OWNER',
    'voice': 'PENGUBAH SUARA',
    'quotes': 'MENU QUOTES',
    'store': 'MENU STORE',
    'stalk': 'MENU STALK',
    'tools': 'MENU TOOLS',
    'anonymous': 'ANONYMOUS CHAT',
    '': 'NO CATEGORY'
}

const defaultMenu = {
    before: `
Hi %name
I am an automated system (WhatsApp Bot) that can help to do something, search and get data / information only through WhatsApp.

◦ *Library:* Baileys
◦ *Function:* Assistant

┌  ◦ Uptime : %uptime
│  ◦ Tanggal : %date
│  ◦ Waktu : %time
└  ◦ Prefix Used : *[ %p ]*
`.trimStart(),
    header: '┌  ◦ *%category*',
    body: '│  ◦ %cmd %islimit %isPremium',
    footer: '└  ',
    after: `*Note:* Ketik .menu <category> untuk melihat menu spesifik\nContoh: .menu tools`
}

let handler = async (m, { conn, usedPrefix: _p, args = [], command }) => {
    try {
        let package = JSON.parse(await fs.promises.readFile(path.join(__dirname, '../package.json')).catch(_ => '{}'))
        let { exp, limit, level, role } = global.db.data.users[m.sender]
        let { min, xp, max } = levelling.xpRange(level, global.multiplier)
        let name = `@${m.sender.split`@`[0]}`
        let teks = args[0] || ''
        
        let d = new Date(new Date + 3600000)
        let locale = 'id'
        let date = d.toLocaleDateString(locale, {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        })
        
        let time = d.toLocaleTimeString(locale, {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric'
        })

        let _uptime = process.uptime() * 1000
        let uptime = clockString(_uptime)
        
        let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
            return {
                help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
                tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
                prefix: 'customPrefix' in plugin,
                limit: plugin.limit,
                premium: plugin.premium,
                enabled: !plugin.disabled,
            }
        })

        if (!teks) {
            let menuList = `${defaultMenu.before}\n\n┌  ◦ *DAFTAR MENU*\n`
            for (let tag of arrayMenu) {
                if (tag && allTags[tag]) {
                    menuList += `│  ◦ ${_p}menu ${tag}\n`
                }
            }
            menuList += `└  \n\n${defaultMenu.after}`

            let replace = {
                '%': '%',
                p: _p, 
                uptime,
                name, 
                date,
                time
            }

            let text = menuList.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), 
                (_, name) => '' + replace[name])

            await conn.relayMessage(m.chat, {
            extendedTextMessage:{
                text: text, 
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: date,
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: pickRandom(gambarnya),
                        sourceUrl: channel
                    }
                }, 
                mentions: [m.sender]
            }
        }, {})
        await conn.sendMessage(m.chat, {
           audio: { url: pickRandom(vnnya) },
           mimetype: 'audio/mpeg',
           ptt: true,
           contextInfo: {
               forwardingScore: 999,
               isForwarded: true,
               externalAdReply: {
                   title: 'ɴᴀʏᴀᴋᴀʙᴏᴛᴢ sɪᴍᴘʟᴇ ᴍᴇɴᴜ',
                   body: wm,
                   sourceUrl: "https://mobile.capcutshare.com/s/Zs86pXs9D",
                   thumbnailUrl: pickRandom(gambarvn)
               }
           }
       }, { quoted: m })
            return
        }

        if (!allTags[teks]) {
            return m.reply(`Menu "${teks}" tidak tersedia.\nSilakan ketik ${_p}menu untuk melihat daftar menu.`)
        }

        let menuCategory = defaultMenu.before + '\n\n'
        
        if (teks === 'all') {
            // category all
            for (let tag of arrayMenu) {
                if (tag !== 'all' && allTags[tag]) {
                    menuCategory += defaultMenu.header.replace(/%category/g, allTags[tag]) + '\n'
                    
                    let categoryCommands = help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help)
                    for (let menu of categoryCommands) {
                        for (let help of menu.help) {
                            menuCategory += defaultMenu.body
                                .replace(/%cmd/g, menu.prefix ? help : _p + help)
                                .replace(/%islimit/g, menu.limit ? '(Ⓛ)' : '')
                                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '') + '\n'
                        }
                    }
                    menuCategory += defaultMenu.footer + '\n'
                }
            }
        } else {
            menuCategory += defaultMenu.header.replace(/%category/g, allTags[teks]) + '\n'
            
            let categoryCommands = help.filter(menu => menu.tags && menu.tags.includes(teks) && menu.help)
            for (let menu of categoryCommands) {
                for (let help of menu.help) {
                    menuCategory += defaultMenu.body
                        .replace(/%cmd/g, menu.prefix ? help : _p + help)
                        .replace(/%islimit/g, menu.limit ? '(Ⓛ)' : '')
                        .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '') + '\n'
                }
            }
            menuCategory += defaultMenu.footer + '\n'
        }

        menuCategory += '\n' + defaultMenu.after
        
        let replace = {
            '%': '%',
            p: _p, 
            uptime, 
            name,
            date,
            time
        }

        let text = menuCategory.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), 
            (_, name) => '' + replace[name])

        await conn.relayMessage(m.chat, {
            extendedTextMessage:{
                text: text, 
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: date,
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: pickRandom(gambarnya),
                        sourceUrl: channel
                    }
                }, 
                mentions: [m.sender]
            }
        }, {})
        await conn.sendMessage(m.chat, {
           audio: { url: pickRandom(vnnya) },
           mimetype: 'audio/mpeg',
           ptt: true,
           contextInfo: {
               forwardingScore: 999,
               isForwarded: true,
               externalAdReply: {
                   title: 'ɴᴀʏᴀᴋᴀʙᴏᴛᴢ sɪᴍᴘʟᴇ ᴍᴇɴᴜ',
                   body: wm,
                   sourceUrl: "https://mobile.capcutshare.com/s/Zs86pXs9D",
                   thumbnailUrl: pickRandom(gambarvn)
               }
           }
       }, { quoted: m })
    } catch (e) {
        conn.reply(m.chat, 'Maaf, menu sedang error', m)
        console.error(e)
    }
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu|help)$/i
handler.exp = 3

module.exports = handler

const gambarnya = [
"https://file.botcahx.eu.org/file/4gacfhyb7hl37rcczzkw.jpg",
"https://file.botcahx.eu.org/file/fbv4p8ynpj4c9oov6f2g.jpg",
"https://file.botcahx.eu.org/file/0byrv2mgxl5tyni4z1ky.jpg",
"https://file.botcahx.eu.org/file/2gos96ols3iyex6ubwmx.jpg",
"https://file.botcahx.eu.org/file/ct602rk6y124r77sbrrz.jpg",
"https://file.botcahx.eu.org/file/046y153yst5oycijprv3.jpg",
"https://file.botcahx.eu.org/file/wz0iu1sy0603ar3uebqv.jpg",
"https://file.botcahx.eu.org/file/wvhhwrtbzna3uouk6pxe.jpg",
"https://file.botcahx.eu.org/file/8sps1f1b9hkqc1bdo7op.jpg",
"https://file.botcahx.eu.org/file/8r59ra94v6a3ye1hviaj.jpg",
"https://file.botcahx.eu.org/file/3ey54fmaxbbgo4v8xdty.jpg",
"https://file.botcahx.eu.org/file/1pbha63nwpf5ti927mra.jpg",
"https://file.botcahx.eu.org/file/rgjkutn8fva5sb0q1ita.jpg",
"https://file.botcahx.eu.org/file/vcztb9qsjvcaaf4mtz4k.jpg",
"https://file.botcahx.eu.org/file/ldusbjd1bdhxd93na6oy.jpg"
]

const gambarvn = [
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZu5hpzXNZR532gzyO6vmrKvbuhGNW7dEib_OGqqwiPv_q49NmaTV2eFri&s=10",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsIae2bfWChz6ITtj6YMMH2ysKbVLLwKWzwQ&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5dhI8YtSFVSERHXiUfg7BjBmqBD0mpPVzWw&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZNZ6U7uzS9-fRD78U-VGJNgR0m5s3a1RK-g&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5MVIsn_f7dYsuMtX9bG6oHU50k2OiF7N_lQ&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXLaq4_lhvfSYuhZdrwpA0R4KnVSjlDdZAyw&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOHZ99kgpGIiLRIobv9DyNrBdetU0bHNwn7w&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxkWMvJVzc0mZNgbuOGfTGg7LlLSHpWjfIpQ&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOzcZzcxmIoyib4VenlZQ81CLXvIfC-7xyBw&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvjxMtrtmM9-IqI7BycT2lgW1_FcFi42uP0Q&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTuFUJligACuXq6YWxiMdTMXLVhdBusMbfX-sOBVkXiVYsCKwjfCkH6tXWz&s=10",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRU3u6iMsJbUfkKtLi6L9jmwaou4UdvzO8OWaIZpHvYtM6CtQ1pVIZExWc&s=10",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcReS6d1h8pP0QuVQn-ScPQbFaoGfJEKviwTNYEfKjlvPAZR27Wj8HRB93P5&s=10",
"https://64.media.tumblr.com/d39e71205dcaa8c9566a4a641df3c3ba/fc09e15a005bc353-5b/s1280x1920/90defd943b0f4c00b6c878e8ae3568e595de590d.png",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFBfwrTGgqf7GJOI0JThsmtS1dVPlN_ufI3w&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0y70DVctIyzKL6Ulrig-Rusau1jHm2Pz_yg&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpH4XP8MlcCoVl4__UCMzFId0EGidOo2r4sg&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlr15Ydi0_JjwdwhyybYZnbcR-QxwgqUCqrA&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6yRag4AZ4dpjeIpKMjQLUTJ6Za88PCnkDmg&usqp=CAU",
"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHv_b1vvgadBuhWWSbILIte7mxGqPy-vrFhw&usqp=CAU"
]

const vnnya = [
"./media/sound/menu.mp3",
"./media/sound/menu2.mp3",
"./media/sound/menu3.mp3",
"./media/sound/menu4.mp3",
"./media/sound/menu5.mp3",
"./media/sound/menu6.mp3",
"./media/sound/menu7.mp3",
"./media/sound/menu8.mp3",
"./media/sound/menu9.mp3",
]

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    if (isNaN(ms)) return '--'
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}