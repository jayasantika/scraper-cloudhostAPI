const { generateWAMessageContent, generateWAMessageFromContent, proto } = require('@adiwajshing/baileys');
let fetch = require('node-fetch');
let handler = async (m, { usedPrefix, command, conn, args }) => {
  if (!args[0]) throw `*🚩 Example:* ${usedPrefix}${command} Zhao Lusi`;
  m.reply(wait)
  try {
    const q = encodeURIComponent(args.join(' '));
    let response = await fetch(`https://api.betabotz.eu.org/api/search/pinterest?text1=${q}&apikey=${btc}`);
    let data = await response.json();   
    let res = data.result;
    if (res.length < 1) return m.reply("Error, Foto Tidak Ditemukan");
    let old = new Date()
    let limit = Math.min(20, res.length);
    let ult = res.splice(0, limit);
    let push = [];
    let i = 1;
    for (let url of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`,
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm,
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: `🍟 *Fetching* : ${((new Date - old) * 1)} ms`,
        hasMediaAttachment: true,
        imageMessage: await createImage(url),
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: `{"display_text":"Sumber Gambar","url": "${url}","merchant_url": "${url}"}`,
          },
        ],
      }),
    });
  }
  
  const bot = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: "*Berikut Adalah Hasil Pencarian Anda Di Pinterest*",
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: `Total Jumlah Pencarian: ${limit}`,
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false,
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: [...push],
            }),
          }),
        },
      },
    },
    {}
  );
  await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });
  } catch (e) {
    throw `${eror}`;
  }
}

handler.help = ['pinterest <keyword>'];
handler.tags = ['internet', 'downloader'];
handler.command = /^(pinterest|pin)$/i;

module.exports = handler;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent(
      { image: { url } },
      { upload: conn.waUploadToServer }
    );
  return imageMessage;
}