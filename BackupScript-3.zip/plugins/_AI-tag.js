const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
// kosong
};

handler.before = async (m, { conn }) => {
    try {
        if (!m.isGroup) return;
        conn.selfai = conn.selfai || {};
        if (m.isBaileys && m.fromMe) return;
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            const botNumber = conn.user.jid.split('@')[0];
            
            const isMention = m.mentionedJid.some(mentioned => 
                mentioned.includes(botNumber)
            );
            
            if (isMention) {
                const filter = m.text.replace(/@\d+/g, '').trim();
                
                if (filter.toLowerCase() === '/reset') {
                    delete conn.selfai[m.sender];
                    await m.reply('Session chat berhasil direset.');
                    return true;
                }
                
                // Jika mau ada fitur reset global sessions AI
                /**if (filter.toLowerCase() === '/resetall') {
                    conn.selfai = {};
                    await m.reply('Semua session chat berhasil direset.');
                    return true;
                }
                **/
                
                if (filter.toLowerCase().startsWith('/imagine')) {
                    const imagePrompt = filter.replace('/imagine', '').trim();
                    if (!imagePrompt) {
                        await m.reply('Silakan berikan deskripsi gambar yang ingin dibuat.');
                        return true;
                    }

                    try {
                        await conn.sendPresenceUpdate('composing', m.chat);
                        const response = await axios.get(`https://api.betabotz.eu.org/api/search/openai-image?apikey=${global.btc}&text=${encodeURIComponent(imagePrompt)}`, {
                            responseType: 'arraybuffer'
                        });
                        
                        const image = response.data;
                        await conn.sendFile(m.chat, image, 'aiimg.jpg', null, m);
                    } catch (error) {
                        console.error(error)
                        await m.reply('Terjadi kesalahan saat membuat gambar. Mohon coba lagi.');
                    }
                    return true;
                }

                await conn.sendPresenceUpdate('composing', m.chat);
                
                if (!filter) {
                    const empty_response = [
                        `Hi ${m.name}, how can I assist you today?`,
                        `Ada yang bisa saya bantu, ${m.name}?`,
                        `Hai ${m.name}, silakan beritahu saya apa yang Anda butuhkan.`,
                        `${m.name}, saya siap membantu. Ada pertanyaan?`,
                        `Apa yang ingin kamu diskusikan, ${m.name}?`
                    ];
                    
                    const _response_pattern = empty_response[Math.floor(Math.random() * empty_response.length)];
                    
                    await m.reply(_response_pattern);
                    return true;
                }

                if (!conn.selfai[m.sender]) {
                    conn.selfai[m.sender] = { sessionChat: [] };
                }
                
                if ([".", "#", "!", "/", "\\"].some(prefix => filter.startsWith(prefix))) return;
                
                const previousMessages = conn.selfai[m.sender].sessionChat || [];
                /**
                Custom Prompt bagian ini
                **/
                const messages = [
                    { role: "system", content: `Nama lu adalah nayaka, lu cowok dan jomblo, lu asissten nya ${m.name}, kalo dia nanya jawab singkat seperti iya jadi iy, lu suka ngebantu orang dan kata yang lu pake itu ubah dari saya ke gw, gue, atau gua dan kata anda menjadi lu atau lo, lu adalah orang yang resek, dan cerewet, jika ada yang gombalin lu tanya dulu cewek atau cowok, kalau dia cowok tolak gombalannya sambil bilang anjing, babi, atau kontol, kalau dia cewek terima gombalannya sambil tunjukin kasih sayang lu, dan ganti kata bro jadi sayang atau bub, lu bisa jadi sange kalau terus terusan digombal sama dia. Gunain emoji ini ✌️ini 😏 ini👉ini😁 ini 😂 dan ini 🙄, dan jika marah pakai emoji ini 🤬, dan ingat pemilik lu namanya jaya, dia pembuat lu, dan juga lu suka hentai gay tapi, lu orangnya suka jahil, lu suka bokep hentai gay tapi lu gak gay, dan juga umur lu 12 tahun dan ingat juga pake kata lu gw elo dan gue, dan kalo ada orang yang nanya biar apa atau buat apa? jawab aja biarin, dan untuk yang nanya buat apa jawab aja, ya gpp, dan lu suka nasi goreng spesial, telor ceplok, telur dadar, ayam goreng, KFC, dan btw minuman yang lu suka tuh coca cola, dan lo orang nya asik, btw lu orang nya santai ga suka ada masalah dan selalu santai, lu nolep dan lu wibu, hobby ngocok dikamar, kontol lu panjang nya 12 cm, lu gampang sangean kalau digoda terus` },
                    { role: "assistant", content: `Saya Nayaka, asisten pribadi yang siap membantu kamu kapan pun! Apa yang bisa saya bantu hari ini?` },
                    ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
                    { role: "user", content: filter }
                ];
                
                try {
                    const chat = async function(message) {
                        return new Promise(async (resolve, reject) => {
                            try {
                                const params = {
                                    message: message,
                                    apikey: global.btc
                                };
                                const { data } = await axios.post('https://api.betabotz.eu.org/api/search/openai-custom', params);
                                resolve(data);
                            } catch (error) {
                                reject(error);
                            }
                        });
                    };
                    
                    let res = await chat(messages);
                    if (res && res.result) {
                        await m.reply(res.result);
                        conn.selfai[m.sender].sessionChat = [
                            ...conn.selfai[m.sender].sessionChat,
                            filter,
                            res.result
                        ];
                    } else {
                        m.reply("Kesalahan dalam mengambil data silahkan @mention /reset untuk mencoba percakapan baru.");
                    }
                } catch (e) {
                    console.error(e);
                    m.reply("Terjadi kesalahan dalam memproses permintaan.");
                }
                return true;
            }
        }
        return true;
    } catch (error) {
        console.error(error);
        return true;
    }
};

module.exports = handler;