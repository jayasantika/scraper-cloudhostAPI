let fetch = require('node-fetch')

let handler = async (m, { conn, args, usedPrefix, command }) => {
   if (!args[0]) throw `Gunakan contoh ${usedPrefix}${command} https://www.facebook.com/watch/?v=1393572814172251`
   await m.reply(wait)
   try {
       const api = await fetch(`https://api.betabotz.eu.org/api/download/fbdown?url=${args[0]}&apikey=${btc}`)
       const res = await api.json()
       
       const limitnya = 3
       
       for (let i = 0; i < Math.min(limitnya, res.result.length); i++) {
           await sleep(3000)
           conn.sendFile(m.chat, res.result[i]._url, null, `*Facebook Downloader*`, m)
       }
   } catch (e) {
       throw eror
   }
}

handler.help = ['facebook'].map(v => v + ' <url>');
handler.command = /^(fb|facebook|facebookdl|fbdl|fbdown|dlfb)$/i;
handler.tags = ['downloader'];
handler.limit = true

module.exports = handler

function sleep(ms) {
   return new Promise(resolve => setTimeout(resolve, ms));
}