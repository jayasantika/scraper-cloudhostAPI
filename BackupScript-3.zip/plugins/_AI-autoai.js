let axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    conn.sessionAI = conn.sessionAI ? conn.sessionAI : {};

    if (!text) throw `🚩 ${usedPrefix + command} *on/off*`;

    if (text === "on") {
        conn.sessionAI[m.sender] = { sessionChat: [] };
        m.reply("Success create sessions chat!");
    } else if (text === "off") {
        delete conn.sessionAI[m.sender];
        m.reply("Success delete sessions chat!");
    }
};

handler.before = async (m, { conn }) => {
    conn.sessionAI = conn.sessionAI ? conn.sessionAI : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.sessionAI[m.sender]) return;
    if ([".", "#", "!", "/", "\\"].some(prefix => m.text.startsWith(prefix))) return;

    if (conn.sessionAI[m.sender] && m.text) {    
    	let name = conn.getName(m.sender);
    	await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
        const previousMessages = conn.sessionAI[m.sender].sessionChat || [];
/**
 * @description Ubah prompt ini sesuai dengan keinginanmu.
 * @note Usahakan memberikan logika yang masuk akal dan mudah dipahami!
 */
        const messages = [
            { role: "system", content: `Lu Adalah Nayaka, Lu Asissten nya ${name}, Kalo Dia Nanya Jawab singkat, seperti iya jadi iy, lu suka ngebantu orang,dan kata yang lu pake itu ubah dari saya ke gw,dan kata anda ke lu atau Lo, dan kamu adalah orang yang resek, dan cerewet, lu bisa bilang anjing, babi, atau kontol, Lo bie pake emoji ini iniiniiniinidan ini , dan jika marah pakai emoji ini , dan Lo bisa bilang nigga, dan ingat owner lu namanya Jaya, Dia Pembuat Lu, dan Lu suka pake bahasa kasar kek, Anj, Babi, Ngent, Asw, Asu, Mmk, Kntl, dan juga lu suka furry, Furry Gay Tapi, lu orangnya Suka Jahil, Lu Suka Bokep Furry Gayz Tapi Lu Gak Gay, Dan juga Umur lu 12 Tahun dan ingat juga pake kata lu gw elo dan gue, dan kalo ada orang yang nanya biar apa atau buat apa? Jawab aja biarin, dan untuk yang nanya buat apa jawab aja, ya gpp, dan lu suka nasi goreng spesial, telor ceplok, telur dadar, ayam goreng, KFC, dan btw minuman yang lu suka tuh Coca Cola, dan Lo Orang Nya Asik, btw lu orang nya santai gk suka ada masalah dan selalu santai, nolep tapi bukan wibu, tapi furry, hobby ngocok dikamar, kontol lu panjang nya 12 cm, Lu Gampang Sangean` },
            { role: "assistant", content: `Saya Nayaka, asisten pribadi yang siap membantu kamu kapan pun! Apa yang bisa saya bantu hari ini?` },
            ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
            { role: "user", content: m.text }
        ];

        try {
            const chat = async function(message) {
                return new Promise(async (resolve, reject) => {
                    try {
                        const params = {
                            message: message,
                            apikey: btc
                        };
                        const { data } = await axios.post('https://api.betabotz.eu.org/api/search/openai-custom', params);
                        resolve(data);
                    } catch (error) {
                        reject(error);
                    }
                });
            };

            let res = await chat(messages);
            if (res && res.result) {
            	await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
                await m.reply(res.result);
                conn.sessionAI[m.sender].sessionChat = [
                    ...conn.sessionAI[m.sender].sessionChat,
                    m.text,
                    res.result
                ];
            } else {
                m.reply("Kesalahan dalam mengambil data");
            }
        } catch (e) {
            throw eror
        }
    }
};

handler.command = ['autoai'];
handler.tags = ['ai'];
handler.help = ['autoai'].map(a => a + ' *on/off*');
handler.limit = true

module.exports = handler;