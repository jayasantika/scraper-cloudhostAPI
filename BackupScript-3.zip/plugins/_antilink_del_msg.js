let handler = async (m, { conn }) => {
    if (!m.isGroup || m.isBaileys || m.fromMe) return // Pastikan hanya berjalan di grup dan bukan dari bot

    let chat = await conn.groupMetadata(m.chat) // Ambil metadata grup
    let isBotAdmin = chat.participants.find(p => p.id === conn.user.jid)?.admin // Periksa apakah bot adalah admin
    let isAdmin = chat.participants.find(p => p.id === m.sender)?.admin // Periksa apakah pengirim adalah admin

    if (!isBotAdmin || isAdmin) return // Jika bot bukan admin atau pengirim adalah admin, abaikan

    await conn.sendMessage(m.chat, { delete: m.key }) // Hapus pesan yang mengandung link grup lain
    await conn.sendMessage(m.chat, { text: `@${m.sender.split('@')[0]} dilarang mengirim link grup lain!`, mentions: [m.sender] })
}

handler.customPrefix = /(https?:\/\/)?(www\.)?(chat.whatsapp.com\/invite\/|chat.whatsapp.com\/)([0-9A-Za-z]{20,24})/i
handler.command = new RegExp()

module.exports = handler