let fetch = require('node-fetch');

let handler = async (m, { conn }) => {
  try {
    await m.reply(wait);

    let api = await fetch(`https://api.betabotz.eu.org/api/checkkey?apikey=${btc}`);
    let body = await api.json();

    let { 
      email, 
      username, 
      limit, 
      role, 
      expired, 
      todayHit, 
      totalHit, 
      dataIP 
    } = body.result;

    let capt = `乂 *C H E C K   A P I K E Y*\n\n`;
    capt += `◦ *Email*: ${email}\n`;
    capt += `◦ *Username*: ${username}\n`;
    capt += `◦ *Limit*: ${limit}\n`;
    capt += `◦ *Role*: ${role}\n`;
    capt += `◦ *Expired*: ${expired}\n`;
    capt += `◦ *Today Hit*: ${todayHit}\n`;
    capt += `◦ *Total Hit*: ${totalHit}\n\n`;

    // Menambahkan data IP
    if (dataIP && dataIP.length > 0) {
      capt += `乂 *D A T A   I P*\n\n`;
      dataIP.forEach((ipData, index) => {
        capt += `◦ *IP ${index + 1}*: ${ipData.ip}\n`;
        capt += `  ├ Whitelisted: ${ipData.whitelisted ? 'Yes' : 'No'}\n`;
        capt += `  ├ Access Type: ${ipData.accessType}\n`;
        capt += `  ├ Count: ${ipData.count}\n`;
        capt += `  ├ Last Used: ${ipData.lastUsed}\n`;
        capt += `  ├ Created At: ${ipData.createdAt}\n\n`;
      });
    }

    await conn.reply(m.chat, capt, m);
  } catch (e) {
    console.error(e);
    await conn.reply(m.chat, 'Terjadi kesalahan saat mengambil data API.', m);
  }
};

handler.command = handler.help = ['checkapi', 'api'];
handler.tags = ['main'];
handler.owner = true;

module.exports = handler;