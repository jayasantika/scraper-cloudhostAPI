/*
By Fruatre
wa.me/6285817597752
Saluran : https://whatsapp.com/channel/0029VaNR2B6BadmioY6mar3N
*/

const {
    generateWAMessage,
    STORIES_JID,
    generateWAMessageFromContent
} = require('@adiwajshing/baileys');
const FileType = require('file-type');

let handler = async (m, { conn, text }) => {
    try {
    	const userId = conn.user?.jid;
        if (!userId) {
        	return m.reply('Koneksi tidak terauntentikasi, silakan lakukan pengambilan sesi ulang')
        }
        
        if (!text) {
            return m.reply('Masukkan format teks yang benar:\n- `.upswtag Pesan =123xxx@g.us` (1 grup)\n- `.upswtag Pesan =123xxx@g.us,456yyy@g.us` (lebih dari 1 grup, maksimal 5)\n- `.upswtag --all` (semua grup)');
        }

        const groups = Object.values(await conn.groupFetchAllParticipating())
            .filter(v => v.participants.find(p => p.id === conn.user.jid) && !v.announce);

        let groupData = [];
        let statusJidList = [];
        const isAll = text.includes("--all");
        const [messageText, groupInput] = text.split('=').map(v => v.trim());

        if (isAll) {
            // Semua grup
            groupData = groups.map(v => v.id);
            statusJidList = groups.flatMap(group => group.participants.map(v => v.id));
        } else if (groupInput) {
            // 1 atau lebih dari 1 grup (maksimal 5)
            const groupIds = groupInput.split(',').map(v => v.trim()).filter(v => v.endsWith('@g.us'));
            if (groupIds.length > 10) {
                return m.reply('Maksimal hanya 10 grup yang diperbolehkan.');
            }
            groupData = groupIds.filter(id => groups.find(g => g.id === id)); // Validasi grup
            if (!groupData.length) {
                return m.reply('Tidak ada ID grup valid yang ditemukan.');
            }
            statusJidList = groupData.flatMap(id => groups.find(g => g.id === id)?.participants.map(v => v.id) || []);
        } else {
            return m.reply('ID grup tidak ditemukan dalam input.');
        }

        const reps = isAll ? messageText.replace("--all", "").trim() : messageText || '@anda disebut';
        let media;
        const content = { caption: reps };

        // Media yang dibalas
        if (m.quoted && (/audioMessage|videoMessage|imageMessage|conversation|extendedTextMessage/.test(m.quoted.mtype))) {
            try {
                media = await m.quoted.download();
                if (!media) {
                    return m.reply('Media gagal diunduh. Pastikan media valid.');
                }
            } catch (error) {
                throw error;
            }

            const mime = await FileType.fromBuffer(media);
            if (mime) {
                if (/image/.test(mime.mime)) {
                    content.image = media;
                    content.mimetype = mime.mime || 'image/jpeg';
                } else if (/video/.test(mime.mime)) {
                    content.video = media;
                    content.mimetype = mime.mime || 'video/mp4';
                } else if (/audio/.test(mime.mime)) {
                    content.audio = media;
                    content.ptt = true;
                    content.mimetype = mime.mime || 'audio/mpeg';
                } else {
                    return m.reply(`Tipe media tidak didukung. MIME type: ${mime.mime}`);
                }
            } else {
                return m.reply('Tipe media tidak terdeteksi. Pastikan media memiliki tipe yang valid.');
            }
        } else if (reps) {
            content.text = reps;
        } else {
            return m.reply('Balas media yang ingin dijadikan story.');
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: '👀',
                key: m.key,
            }
        })
        const { success, failed } = await sendStatusMention(content, groupData, statusJidList);

        await conn.reply(m.chat, `Berhasil mengirim cerita:
- ${statusJidList.length} User.
- ${groupData.length} Grup.
[Sukses: ${success}${failed > 0 ? '\nGagal: ' + failed : ''}]`, m);
        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key,
            }
        })
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan:\n' + error.message);
    }
};

handler.help = handler.command = ["upswtag2"];
handler.tags = ["owner"];
handler.rowner = true;

module.exports = handler;

const sendStatusMention = async (content, groupData, statusJidList) => {
    let success = 0,
        failed = 0,
        index = 0;

    if (!content.image && !content.video && !content.audio && !content.text) {
        throw new Error("Media atau teks tidak ditemukan.");
    }

    const media = await generateWAMessage(STORIES_JID, content, {
        upload: conn.waUploadToServer,
    });
    const groupStages = await itemStages(groupData);

    for (const groupId of groupStages) {
        const additionalNodes = [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: groupId.map((jid) => ({
                    tag: "to",
                    attrs: { jid },
                    content: undefined,
                })),
            }],
        }];

        for (const jid of groupId) {
            try {
                const msg = await generateWAMessageFromContent(jid, {
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: media.key,
                                type: 25,
                            },
                        },
                    },
                }, {});
                await conn.relayMessage(jid, msg.message, {
                    additionalNodes: [{
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    }],
                });
                success++;
            } catch (error) {
                failed++;
            }

            index++;
            const delay = (index % 10 === 0) ? 30000 : 3000;
            await new Promise(resolve => setTimeout(resolve, delay));
        }

        await conn.relayMessage(STORIES_JID, media.message, {
            messageId: media.key.id,
            statusJidList,
            additionalNodes,
        });
        await new Promise(resolve => setTimeout(resolve, 5000));
    }

    return { success, failed };
};

function itemStages(itemArray) {
    const hasil = [];
    for (let index = 0; index < itemArray.length; index += 5) {
        const stage = itemArray.slice(index, index + 5);
        hasil.push(stage);
    }
    return hasil;
}