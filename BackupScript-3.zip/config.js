global.owner = ['6289524664142', '6285852189768', '6282339922441', '216169999016014', '95460446478399', '159051732222039']  
global.mods = ['6289524664142', '216169999016014'] 
global.prems = ['6289524664142', '216169999016014']
global.nameowner = 'Jaya'
global.numberowner = '6289524664142' 
global.mail = 'jayaxyz16@gmail.com' 
global.gc = 'https://chat.whatsapp.com/K4THD5ExUFR2166wKiiGfR'
global.channel = 'https://whatsapp.com/channel/0029VaIEufDK0IBrsQWOCO3g'
global.instagram = 'https://instagram.com/jayaaa_2606'
global.wm = '© NayakaBotz-Md'
global.wait = '```Memproses permintaan anda. Silakan tunggu sebentar...```'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With NayakaBotz'
global.author = 'wa.me/6282339922441'
global.maxwarn = '5' // Peringatan maksimum Warn

global.autobio = false // Set true/false untuk mengaktifkan atau mematikan autobio (default: false)
global.antiporn = false // Set true/false untuk Auto delete pesan porno (bot harus admin) (default: true)
global.spam = true // Set true/false untuk anti spam (default: true)
global.gcspam = false // Set true/false untuk menutup grup ketika spam (default: false)
    

// APIKEY INI WAJIB DI ISI! //
global.btc = 'Fruatre-Btz' 
//Daftar terlebih dahulu https://api.botcahx.eu.org



// INI HANYA OPTIONAL SAJA BOLEH DI ISI BOLEH JUGA ENGGA //
global.lann = 'Fruatre-Btz'
//Daftar https://api.betabotz.eu.org 

//Gausah diganti atau di ubah
global.APIs = {   
  btc: 'https://api.betabotz.eu.org'
}

//Gausah diganti atau di ubah
global.APIKeys = { 
  'https://api.betabotz.eu.org': global.lann
}


let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
