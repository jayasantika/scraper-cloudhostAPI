const fs = require('fs');
const path = require('path');
const logger = require('./lib/logger');
const settings = require('./settings');

global.commandPlugins = [];
global.hookPlugins = [];

/**
 * Ambil semua file .js secara rekursif
 */
function getFiles(dir) {
  let results = [];
  fs.readdirSync(dir).forEach(file => {
    const full = path.join(dir, file);
    if (fs.statSync(full).isDirectory()) {
      results = results.concat(getFiles(full));
    } else if (file.endsWith('.js')) {
      results.push(full);
    }
  });
  return results;
}

/**
 * Load semua plugin
 */
function loadPlugins() {
  global.commandPlugins = [];
  global.hookPlugins = [];

  const pluginDir = path.join(__dirname, 'plugins');
  const files = getFiles(pluginDir);

  for (const file of files) {
    try {
      delete require.cache[require.resolve(file)];
      const mod = require(file);

      if (mod.exec && Array.isArray(mod.cmd)) {
        commandPlugins.push(mod);
      }

      if (typeof mod.before === 'function') {
        hookPlugins.push(mod.before);
      }

      logger.debug(`✅ Plugin loaded: ${path.relative(pluginDir, file)}`);
    } catch (err) {
      logger.error(`❌ Gagal load plugin: ${file}`, err);
    }
  }
}

/**
 * Watch folder plugins untuk auto-reload
 */
function watchPlugins(dir) {
  const chokidar = require('chokidar');

  const watcher = chokidar.watch(dir, {
    ignored: /(^|[\/\\])\../, // abaikan file hidden
    persistent: true,
    ignoreInitial: true,
    depth: 99
  });

  watcher.on('change', (filePath) => {
    if (filePath.endsWith('.js')) {
      try {
        delete require.cache[require.resolve(filePath)];
        const mod = require(filePath);

        if (mod.exec && Array.isArray(mod.cmd)) {
          // hapus command lama dengan cmd yang sama
          commandPlugins = commandPlugins.filter(p => !p.cmd.some(c => mod.cmd.includes(c)));
          commandPlugins.push(mod);
        }

        if (typeof mod.before === 'function') {
          hookPlugins = hookPlugins.filter(fn => fn !== mod.before);
          hookPlugins.push(mod.before);
        }

        logger.info(`🔄 Reloaded plugin: ${path.relative(dir, filePath)}`);
      } catch (err) {
        logger.error(`❌ Gagal reload plugin ${filePath}`, err);
      }
    }
  });

  watcher.on('error', error => logger.error('Watcher error:', error));
}

/**
 * Untuk event plugin seperti .register(bot)
 */
function loadEvents(bot) {
  const pluginDir = path.join(__dirname, 'plugins');
  getFiles(pluginDir).forEach(file => {
    const mod = require(file);
    if (typeof mod.register === 'function') {
      try {
        mod.register(bot);
        logger.debug(`✅ Event registered: ${path.relative(pluginDir, file)}`);
      } catch (err) {
        logger.error(`❌ Error registering events in ${file}`, err);
      }
    }
  });
}

/**
 * Statistik plugin
 */
function getPluginStats() {
  return {
    command: commandPlugins.length,
    hook: hookPlugins.length
  };
}

/**
 * Handler utama untuk command
 */
async function handleUpdate(bot, msg) {
  const text = msg.text || '';

  for (const before of hookPlugins) {
    try {
      await before(bot, msg);
    } catch (err) {
      logger.error('Error in before hook', err);
    }
  }

  if (text.startsWith(settings.prefix)) {
    const parts = text
      .slice(settings.prefix.length)
      .trim()
      .split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    for (const plugin of commandPlugins) {
      if (plugin.cmd.includes(cmd)) {
        try {
          await plugin.exec(bot, {
            msg,
            cmd,
            args,
            loadedPlugins: commandPlugins,
          });
          logger.command(msg);
        } catch (err) {
          logger.error('Error executing command', err);
          bot.sendMessage(msg.chat.id, '⚠️ Error executing command.');
        }
        break;
      }
    }
  }

  // Tambahkan ini untuk plugin yang pakai onMessage
  for (const plugin of commandPlugins) {
    if (typeof plugin.onMessage === 'function') {
      try {
        await plugin.onMessage(msg, bot);
      } catch (err) {
        logger.error('Error in plugin.onMessage', err);
      }
    }
  }
}

async function handleCallbackQuery(bot, query) {
  const data = query.data || '';
  const command = data.split(/[:|]/)[0];

  for (const plugin of commandPlugins) {
    const isMatch =
      typeof plugin.callback === 'function' &&
      (
        plugin.cmd.some(c => command === c || command.startsWith(c)) || // fleksibel cocok awalannya
        plugin.callbackPrefix === command // khusus kalau ditentukan langsung
      );

    if (isMatch) {
      try {
        await plugin.callback(bot, { query, command });
      } catch (err) {
        logger.error('Error in plugin.callback', err);
        await bot.answerCallbackQuery(query.id, {
          text: '❌ Terjadi kesalahan saat memproses tombol!',
          show_alert: true
        });
      }
      return;
    }
  }

  // Tidak ditemukan plugin yang cocok
  await bot.answerCallbackQuery(query.id, {
    text: '🚫 Aksi tidak dikenal.',
    show_alert: true
  });
}

module.exports = { handleUpdate, handleCallbackQuery, loadEvents, loadPlugins, watchPlugins, getPluginStats };