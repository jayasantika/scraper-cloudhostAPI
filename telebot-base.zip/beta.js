const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const express = require('express');
const app = express();
const settings = require('./settings.js');
const chalk = require('chalk');
const figlet = require('figlet');
const logger = require('./lib/logger');
const { handleUpdate, handleCallbackQuery, loadEvents, watchPlugins, loadPlugins, getPluginStats } = require('./handler');

process.env.NTBA_FIX_319 = '1';

const botToken = settings.telegramBotToken;
const ownerName = settings.ownerUsernames;
const ownerNumber = settings.ownerNumber;
const mess = settings.mess;
const imageUrl = settings.imageUrl;
const buttonUrl = settings.buttonUrl;
const api = settings.api;
const apikey = settings.apikey;

const bot = new TelegramBot(botToken, { polling: true });
const port = process.env.PORT || 9876;

const loadedPlugins = [];

bot.on('callback_query', (query) => {
  handleCallbackQuery(bot, query);
});

bot.on('polling_error', (error) => {
  logger.info(`Polling error: ${error.message}`);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled rejection', reason);
});

loadPlugins();

watchPlugins(path.join(__dirname, 'plugins'));

loadEvents(bot);

(async () => {
  try {
    const owner = Number(settings.ownerId);
    const stats = getPluginStats();
    await bot.sendMessage(owner,
      `🤖 Bot Connected\n\n📦 Plugins loaded:\n` +
      `> Command: ${stats.command}\n` +
      `> Hooks: ${stats.hook}`
    );
  } catch (err) {
    logger.error('Failed to send startup message to owner', err);
  }
})();

const options = {
  reply_markup: {
    inline_keyboard: [
      [{ text: 'Script Bot', url: buttonUrl }],
    ],
  },
};

bot.on('new_chat_members', async (msg) => {
  const chatId = msg.chat.id;
  const newUser = msg.new_chat_members[0];
  const profilePhoto = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';

  const welcomeMessage = `
🎉 Hai ${newUser.username}! 🎉
Selamat datang di grup ${msg.chat.title}.
Jam: ${new Date(msg.date * 1000).toLocaleTimeString()}
Hari: ${new Date(msg.date * 1000).toLocaleDateString()}
Semoga betah yaa. 😊
  `;

  bot.sendPhoto(chatId, profilePhoto, { caption: welcomeMessage, ...options });
});

bot.on('left_chat_member', async (msg) => {
  const chatId = msg.chat.id;
  const leftUser = msg.left_chat_member;
  const profilePhoto = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';

  const goodbyeMessage = `
👋 Goodbye ${leftUser.username}!
Selamat tinggal di grup ${msg.chat.title}.
Jam: ${new Date(msg.date * 1000).toLocaleTimeString()}
Hari: ${new Date(msg.date * 1000).toLocaleDateString()}
Semoga tenang di sana. 😢
  `;

  bot.sendPhoto(chatId, profilePhoto, { caption: goodbyeMessage, ...options });
});

// Load plugin secara rekursif dari subfolder plugins
const isOwner = (username) => settings.ownerUsernames.includes(username);
const isGroup = (msg) => msg.chat.type.includes('group');

const walkPlugins = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(walkPlugins(fullPath));
    } else if (file.endsWith('.js')) {
      results.push(fullPath);
    }
  }
  return results;
};

const pluginsPath = path.join(__dirname, 'plugins');
const pluginFiles = walkPlugins(pluginsPath);

for (const file of pluginFiles) {
  try {
    const plugin = require(file);
    if (plugin.exec) {
      loadedPlugins.push(plugin);
    }
    if (plugin.init) {
      plugin.init(bot, {
        isOwner,
        isGroup,
        logger,
        figlet,
        loadedPlugins,
        mess,
        buttonUrl,
        imageUrl,
        api,
        apikey,
        ownerName,
        ownerNumber
      });
    }
  } catch (err) {
    console.error(`❌ Error loading plugin ${file}:`, err.message);
  }
}

bot.on('message', msg => handleUpdate(bot, msg, loadedPlugins));

// Express endpoint
app.set('json spaces', 2);
app.get('/', (req, res) => {
  res.json({
    response: {
      status: 'true',
      message: `Telegram Bot Successfully Activated!`,
      author: 'Lann',
    }
  });
});

function listenOnPort(port) {
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  app.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Port ${port} is already in use. Trying another port...`);
      listenOnPort(port + 1);
    } else {
      console.error(err);
    }
  });
}

listenOnPort(port);