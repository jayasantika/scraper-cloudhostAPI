const fetch = require('node-fetch');
const uploader = require('../../lib/uploader.js');

module.exports = {
  cmd: ['jadianime', 'toanime'],
  tags: ['tools'],
  exec: async (bot, { msg }) => {
    const { api, apikey, mess } = require('../../settings');
    const chatId = msg.chat.id;

    const photo = msg.reply_to_message?.photo?.at(-1);

    if (!photo) {
      return bot.sendMessage(chatId, '📷 Balas foto dengan perintah /jadianime atau /toanime', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const fileStream = bot.getFileStream(photo.file_id);
      const buffers = [];

      fileStream.on('data', chunk => buffers.push(chunk));

      fileStream.on('end', async () => {
        try {
          const photoBuffer = Buffer.concat(buffers);
          const uploadedUrl = await uploader(photoBuffer);

          const apiUrl = `${api}/api/maker/jadianime?url=${encodeURIComponent(uploadedUrl)}&apikey=${apikey}`;
          const res = await fetch(apiUrl);
          const json = await res.json();

          if (!json.result?.img_1 || !json.result?.img_2) {
            throw new Error('Gagal mendapatkan gambar dari API');
          }

          const [img1, img2] = await Promise.all([
            fetch(json.result.img_1).then(r => r.buffer()),
            fetch(json.result.img_2).then(r => r.buffer())
          ]);

          await bot.sendMediaGroup(chatId, [
            { type: 'photo', media: img1 },
            { type: 'photo', media: img2 }
          ], {
            reply_to_message_id: msg.message_id
          });

        } catch (err) {
          console.error('Anime conversion error:', err);
          bot.sendMessage(chatId, mess.eror || '❌ Gagal mengubah foto menjadi anime.', {
            reply_to_message_id: msg.message_id
          });
        }
      });

      fileStream.on('error', err => {
        console.error('Stream error:', err);
        bot.sendMessage(chatId, '❌ Gagal membaca foto.', {
          reply_to_message_id: msg.message_id
        });
      });

    } catch (err) {
      console.error('GetFile error:', err);
      bot.sendMessage(chatId, mess.eror || '❌ Terjadi kesalahan saat mengambil file.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
