const fetch = require('node-fetch');
const uploader = require('../../lib/uploader.js');

module.exports = {
  cmd: ['putihkan', 'toputih'],
  tags: ['tools'],
  exec: async (bot, { msg }) => {
    const { api, apikey, mess } = require('../../settings');
    const chatId = msg.chat.id;

    const photo = msg.reply_to_message?.photo?.at(-1);

    if (!photo) {
      return bot.sendMessage(chatId, '📷 Balas foto dengan perintah /putihkan atau /toputih', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const fileStream = bot.getFileStream(photo.file_id);
      const buffers = [];

      fileStream.on('data', chunk => buffers.push(chunk));

      fileStream.on('end', async () => {
        try {
          const photoBuffer = Buffer.concat(buffers);
          const uploadedUrl = await uploader(photoBuffer);

          const apiUrl = `${api}/api/maker/jadiputih?url=${encodeURIComponent(uploadedUrl)}&apikey=${apikey}`;
          const response = await fetch(apiUrl);

          if (!response.ok) throw new Error(`API Error: ${response.status}`);

          const imageBuffer = await response.buffer();

          await bot.sendPhoto(chatId, imageBuffer, {
            reply_to_message_id: msg.message_id
          });

        } catch (err) {
          console.error('Conversion error:', err);
          bot.sendMessage(chatId, mess.eror || '❌ Terjadi kesalahan saat konversi.', {
            reply_to_message_id: msg.message_id
          });
        }
      });

      fileStream.on('error', err => {
        console.error('Stream error:', err);
        bot.sendMessage(chatId, '❌ Gagal membaca foto.', {
          reply_to_message_id: msg.message_id
        });
      });

    } catch (err) {
      console.error('GetFile error:', err);
      bot.sendMessage(chatId, mess.eror || '❌ Terjadi kesalahan saat mengambil file.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
