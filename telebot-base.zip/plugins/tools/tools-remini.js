const fetch = require('node-fetch');
const uploader = require('../../lib/uploader.js');
const { api, apikey, mess } = require('../../settings');

module.exports = {
  cmd: ['remini', 'hd'],
  tags: ['tools'],

  exec: async (bot, { msg }) => {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.photo) {
      return bot.sendMessage(
        chatId,
        '📷 Balas foto dengan perintah /remini atau /hd',
        { reply_to_message_id: msg.message_id }
      );
    }

    const photoFile = msg.reply_to_message.photo.slice(-1)[0];
    const fileId = photoFile.file_id;

    bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });

    try {
      const fileStream = bot.getFileStream(fileId);
      const buffers = [];

      fileStream.on('data', chunk => buffers.push(chunk));

      fileStream.on('end', async () => {
        try {
          const photoBuffer = Buffer.concat(buffers);
          const uploadedUrl = await uploader(photoBuffer);

          const apiUrl = `${api}/api/tools/remini?url=${encodeURIComponent(uploadedUrl)}&apikey=${apikey}`;
          const response = await fetch(apiUrl);

          if (!response.ok) throw new Error(`API Error ${response.status}`);
          const json = await response.json();

          if (!json.url) throw new Error('Hasil URL dari API tidak ditemukan');

          const hdBuffer = await (await fetch(json.url)).buffer();
          bot.sendPhoto(chatId, hdBuffer, { reply_to_message_id: msg.message_id });

        } catch (err) {
          console.error('Remini Error:', err);
          bot.sendMessage(chatId, mess.eror || '❌ Gagal meng-HD-kan gambar.', {
            reply_to_message_id: msg.message_id
          });
        }
      });

      fileStream.on('error', err => {
        console.error('Stream Error:', err);
        bot.sendMessage(chatId, '❌ Gagal membaca foto.', {
          reply_to_message_id: msg.message_id
        });
      });

    } catch (error) {
      console.error('GetFile Error:', error);
      bot.sendMessage(chatId, mess.eror || '❌ Terjadi kesalahan saat mengambil file.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
