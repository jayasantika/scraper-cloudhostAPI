const fetch = require('node-fetch');
const moment = require('moment-timezone');
const uploader = require('../../lib/uploader');

module.exports = {
  cmd: ['upload', 'tourl'],
  tags: ['tools'],

  exec: async (bot, { msg }) => {
    const chatId = msg.chat.id;

    const isCaptionCmd = typeof msg.caption === 'string' && /^\/(upload|tourl)$/i.test(msg.caption);
    const isReplyCmd = typeof msg.text === 'string' &&
      /^\/(upload|tourl)$/i.test(msg.text) &&
      msg.reply_to_message &&
      (msg.reply_to_message.photo || msg.reply_to_message.video || msg.reply_to_message.document);

    if (!isCaptionCmd && !isReplyCmd) {
      return bot.sendMessage(chatId, '📤 Balas media dengan `/upload` atau dengan `/tourl`.', {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });
    }

    const mediaMsg = isCaptionCmd ? msg : msg.reply_to_message;
    const now = moment().tz('Asia/Jakarta');

    await bot.sendMessage(chatId, '⏳ Mengunggah media...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const fileId =
        mediaMsg.photo?.at(-1)?.file_id ||
        mediaMsg.document?.file_id ||
        mediaMsg.video?.file_id;

      if (!fileId) {
        return bot.sendMessage(chatId, '❌ Media tidak didukung.', {
          reply_to_message_id: msg.message_id
        });
      }

      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const buffer = await (await fetch(fileUrl)).buffer();
      const uploadedLink = await uploader(buffer);
      const fileSizeMB = (buffer.length / 1024 / 1024).toFixed(2);

      const sender = msg.from.username
        ? `https://t.me/${msg.from.username}`
        : `tg://user?id=${msg.from.id}`;

      const replyText = [
        `✅ *Berhasil diupload!*`,
        `👤 Pengirim: [Klik di sini](${sender})`,
        `📦 Ukuran: ${fileSizeMB} MB`,
        `🌐 Link: ${uploadedLink}`,
        ``,
        `🕒 Waktu: ${now.format('HH:mm:ss')}`,
        `📅 Hari: ${now.format('dddd, DD MMMM YYYY')}`
      ].join('\n');

      if (buffer.length > 50 * 1024 * 1024) {
        return bot.sendMessage(chatId, replyText, {
          reply_to_message_id: msg.message_id,
          parse_mode: 'Markdown'
        });
      }

      await bot.sendDocument(chatId, buffer, {
        caption: replyText,
        parse_mode: 'Markdown',
        reply_to_message_id: msg.message_id
      });

    } catch (err) {
      console.error('Upload Error:', err);
      bot.sendMessage(chatId, '❌ Gagal mengupload media.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
