const { performance } = require('perf_hooks');
const osu = require('node-os-utils');
const { mess } = require('../../settings');

module.exports = {
  cmd: ['status', 'statusbot', 'botstatus'],
  tags: ['info'],

  exec: async (bot, { msg, command }) => {
    const chatId = msg.chat.id;
    const NotDetect = 'Not Detect';
    const old = performance.now();

    // Inisialisasi OS utils
    const cpu = osu.cpu;
    const drive = osu.drive;
    const mem = osu.mem;
    const netstat = osu.netstat;
    const OS = osu.os.platform();
    const cpuModel = cpu.model();
    const cpuCore = cpu.count();

    // Gunakan Promise.all untuk paralel
    let [cpuPer, driveInfo, memInfo, netInfo] = await Promise.all([
      cpu.usage().catch(() => NotDetect),
      drive.info().catch(() => null),
      mem.info().catch(() => null),
      netstat.inOut().catch(() => null)
    ]);

    const newTime = performance.now();

    const driveUsed = driveInfo ? driveInfo.usedGb : NotDetect;
    const driveTotal = driveInfo ? `${driveInfo.totalGb} GB` : NotDetect;
    const drivePer = driveInfo ? `${driveInfo.usedPercentage}%` : NotDetect;

    const ramUsed = memInfo ? memInfo.usedMemMb : NotDetect;
    const ramTotal = memInfo ? `${memInfo.totalMemMb} MB` : NotDetect;

    const netsIn = netInfo ? `${netInfo.total.inputMb} MB` : NotDetect;
    const netsOut = netInfo ? `${netInfo.total.outputMb} MB` : NotDetect;

    const ramPercent = (memInfo && memInfo.totalMemMb && memInfo.usedMemMb)
      ? `${Math.round(100 * (memInfo.usedMemMb / memInfo.totalMemMb))}%`
      : NotDetect;

    const ping = Math.round(newTime - old);

    const statusText = `
*「 Bot Status 」*

📟 OS: *${OS}*
🧠 CPU Model: *${cpuModel}*
🧩 CPU Core: *${cpuCore} Core*
⚙️ CPU Usage: *${cpuPer}%*

🧮 RAM: *${ramUsed} / ${ramTotal} (${ramPercent})*
💽 Drive: *${driveUsed} / ${driveTotal} (${drivePer})*

📶 Internet IN: *${netsIn}*
📤 Internet OUT: *${netsOut}*
📡 Ping: *${ping} ms*
`.trim();

    await bot.sendMessage(chatId, mess.wait || '⏳ Tunggu sebentar...', {
      reply_to_message_id: msg.message_id
    });

    await bot.sendPhoto(chatId, 'https://telegra.ph/file/ec8cf04e3a2890d3dce9c.jpg', {
      caption: statusText,
      parse_mode: 'Markdown',
      reply_to_message_id: msg.message_id
    });
  }
};
