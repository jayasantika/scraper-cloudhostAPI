const { ownerUsernames, ownerNumber } = require('../../settings');

module.exports = {
  cmd: ['owner', 'creator'],
  tags: ['info'],
  exec: async (bot, { msg }) => {
    const chatId = msg.chat.id;
    const user = msg.from;

    const caption = `Hi ${user.first_name}! This is my owner\nThe name is: ${ownerUsernames}\nThe number is: ${ownerNumber}`;
    
    const replyMarkup = {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'My Owner', url: `https://t.me/${ownerUsernames}` }],
        ],
      },
    };

    await bot.sendMessage(chatId, caption, {
      reply_to_message_id: msg.message_id,
      ...replyMarkup
    });
  }
};
