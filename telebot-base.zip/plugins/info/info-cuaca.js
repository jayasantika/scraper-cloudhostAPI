const fetch = require('node-fetch');
const { apikey, api, mess } = require('../../settings');

module.exports = {
  cmd: ['cuaca', 'weather'],
  tags: ['info'],

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const query = args.join(' ').trim();

    if (!query) {
      return bot.sendMessage(chatId, `❗ Contoh penggunaan:\n/cuaca Jakarta`, {
        reply_to_message_id: msg.message_id
      });
    }

    // Kirim respon tunggu dulu
    await bot.sendMessage(chatId, mess.wait || '⏳ Tunggu sebentar...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const url = `${api}/api/tools/cuaca?query=${encodeURIComponent(query)}&apikey=${apikey}`;
      const res = await fetch(url);
      if (!res.ok) throw 'Respon tidak valid';

      const json = await res.json();
      if (!json.status || json.code !== 200) throw 'Lokasi tidak ditemukan';

      const result = json.result;
      const cuacaText = `📍 *Cuaca di ${result.location}, ${result.country}*\n\n🌤️ Cuaca: ${result.weather}\n🌡️ Suhu saat ini: ${result.currentTemp}\n🔺 Suhu tertinggi: ${result.maxTemp}\n🔻 Suhu terendah: ${result.minTemp}\n💧 Kelembapan: ${result.humidity}\n🌬️ Angin: ${result.windSpeed}`;

      await bot.sendMessage(chatId, cuacaText, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });

    } catch (err) {
      console.error('Weather Error:', err);
      bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mencari info cuaca. Coba lagi nanti.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
