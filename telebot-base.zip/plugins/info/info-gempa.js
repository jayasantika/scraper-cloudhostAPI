const fetch = require('node-fetch');
const uploader = require('../../lib/uploader');
const { apikey, api, mess } = require('../../settings');

module.exports = {
  cmd: ['infogempa', 'gempa'],
  tags: ['info'],

  exec: async (bot, { msg }) => {
    const chatId = msg.chat.id;

    await bot.sendMessage(chatId, mess.wait || '⏳ Mengambil data gempa...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const res = await fetch(`${api}/api/search/gempa?apikey=${apikey}`);
      const json = await res.json();
      const data = json.result?.result;

      if (!data || !data.image) throw new Error('Data gempa tidak valid');

      const mapsUrl = `https://maps.google.com/?q=${encodeURIComponent(data.Lintang)},${encodeURIComponent(data.Bujur)}`;
      const bmkgUrl = 'https://www.bmkg.go.id/gempabumi/gempabumi-terkini.bmkg';

      const caption = [
        '*📍 Informasi Gempa Terkini*',
        '',
        `🕒 *Waktu:* ${data.waktu}`,
        `📍 *Wilayah:* ${data.Wilayah}`,
        `📏 *Magnitudo:* ${data.Magnitudo}`,
        `📐 *Kedalaman:* ${data.Kedalaman}`,
        `🧽 *Koordinat:* ${data.Lintang}, ${data.Bujur}`,
        `📝 *Potensi:* ${data.Potensi}`
      ].join('\n');

      // Coba upload gambar jika langsung buffer gagal
      const image = await fetch(data.image);
      const buffer = await image.buffer();
      const uploadedUrl = await uploader(buffer);

      await bot.sendPhoto(chatId, uploadedUrl, {
        caption,
        parse_mode: 'Markdown',
        reply_to_message_id: msg.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🌐 BMKG', url: bmkgUrl },
              { text: '📍 Google Maps', url: mapsUrl }
            ]
          ]
        }
      });

    } catch (e) {
      console.error('Gempa Error:', e);
      bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengambil data gempa.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
