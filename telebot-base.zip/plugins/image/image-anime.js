const axios = require('axios');
const { api, apikey, mess } = require('../../settings');

module.exports = {
  cmd: [
    'umaru','keneki','megumin','yotsuba','shinomiya','yumeko','tejina','chiho','toukachan','akira','itori','kurumi','sagiri','eba','deidara','itachi','madara','asuna','ayuzawa','chitoge','emilia','hestia','inori','ana','miku','kaori','shizuka','doraemon','kaga','koturi','mikasa','akiyama','gremory','isuzu','shina','kagura','shinka','tsunade','sasuke','sakura','rize','nezuko','boruto','naruto','erza','minato','elaina','yuri','shota','waifu','loli','hinata','husbu'
  ],
  tags: ['image'],
  callbackPrefix: 'anime_reload',

  exec: async (bot, { msg, cmd }) => {
    const character = cmd.toLowerCase();
    const chatId = msg.chat.id;

    await bot.sendMessage(chatId, mess.wait || '⏳ Sedang mencari gambar...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const url = `${api}/api/anime/${character}?apikey=${apikey}`;
      const response = await axios.get(url, { responseType: 'arraybuffer' });

      const fileName = `${character}.jpg`;
      const caption = `🖼️ Gambar: ${character}`;

      await bot.sendPhoto(chatId, response.data, {
        caption,
        reply_to_message_id: msg.message_id,
        reply_markup: {
          inline_keyboard: [[
            { text: '🔁 Muat ulang', callback_data: `anime_reload|${character}` }
          ]]
        }
      }, {
        filename: fileName,
        contentType: 'image/jpeg'
      });

    } catch (err) {
      console.error('Anime image error:', err);
      await bot.sendMessage(chatId, '❌ Gagal mengambil gambar.', {
        reply_to_message_id: msg.message_id
      });
    }
  },

  callback: async (bot, { query }) => {
    const [_, character] = query.data.split('|');
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    await bot.answerCallbackQuery(query.id);

    await bot.sendMessage(chatId, '⏳ Memuat ulang gambar...', {
      reply_to_message_id: messageId
    });

    try {
      const url = `${api}/api/anime/${character}?apikey=${apikey}`;
      const response = await axios.get(url, { responseType: 'arraybuffer' });

      const fileName = `${character}.jpg`;
      const caption = `🖼️ Gambar: ${character}`;

      await bot.sendPhoto(chatId, response.data, {
        caption,
        reply_to_message_id: messageId,
        reply_markup: {
          inline_keyboard: [[
            { text: '🔁 Muat ulang', callback_data: `anime_reload|${character}` }
          ]]
        }
      }, {
        filename: fileName,
        contentType: 'image/jpeg'
      });

    } catch (err) {
      console.error('Callback image error:', err);
      await bot.sendMessage(chatId, '❌ Gagal memuat ulang gambar.', {
        reply_to_message_id: messageId
      });
    }
  }
};
