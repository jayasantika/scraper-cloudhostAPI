const fs = require('fs');
const path = require('path');
const { mess, ownerUsernames, ownerId } = require('../../settings');

module.exports = {
  cmd: ['sf'],
  tags: ['owner'],

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const username = msg.from?.username?.toLowerCase();
    const userId = msg.from?.id.toString();
    const isOwner = userId === ownerId || ownerUsernames.includes(username);

    if (!isOwner) {
      return bot.sendMessage(chatId, mess.owner, {
        reply_to_message_id: msg.message_id,
      });
    }

    const filePath = args.join(' ').trim();
    if (!filePath) {
      return bot.sendMessage(chatId, '📥 Mau simpan ke mana nih?\n\nContoh:\n`/sf plugins/namafile.js`', {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown',
      });
    }

    const reply = msg.reply_to_message;
    if (!reply?.text) {
      return bot.sendMessage(chatId, '❗ Harus *reply ke pesan teks* berisi kode/isi file!', {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });
    }

    try {
      const fullPath = path.resolve(filePath);
      const dir = path.dirname(fullPath);
      fs.mkdirSync(dir, { recursive: true });

      fs.writeFileSync(fullPath, reply.text);

      bot.sendMessage(chatId, `✅ Berhasil disimpan ke *${filePath}*`, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });

    } catch (err) {
      console.error('Save file error:', err);
      bot.sendMessage(chatId, `❌ Gagal menyimpan file:\n\`${err.message}\``, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });
    }
  }
};
