const usersMap = new Map();
const { mess, ownerUsernames, ownerId } = require('../../settings');

module.exports = {
  cmd: ['broadcast', 'bc'],
  tags: ['owner'],

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username?.toLowerCase(); // untuk membandingkan case-insensitive

    // Validasi owner berdasarkan ID dan username
    const isOwner = userId.toString() === ownerId || ownerUsernames.includes(username);

    if (!isOwner) {
      return bot.sendMessage(chatId, mess.owner, {
        reply_to_message_id: msg.message_id,
      });
    }

    const inputText = args.join(' ').trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input pesan yang mau dibroadcast!\nContoh:\n/bc Halo semua!', {
        reply_to_message_id: msg.message_id,
      });
    }

    if (usersMap.size === 0) {
      return bot.sendMessage(chatId, '📭 Belum ada pengguna yang bisa dikirimi broadcast.', {
        reply_to_message_id: msg.message_id,
      });
    }

    bot.sendMessage(chatId, `📢 Mengirim broadcast ke *${usersMap.size}* user...`, {
      reply_to_message_id: msg.message_id,
      parse_mode: 'Markdown'
    });

    for (const [userId] of usersMap.entries()) {
      try {
        await bot.sendMessage(userId, inputText);
      } catch (e) {
        console.warn(`Gagal kirim ke ${userId}:`, e.message);
      }
    }
  },

  onMessage: (msg) => {
    const userId = msg.from.id;
    const userInfo = {
      username: msg.from.username || 'unknown',
      userId: msg.from.id,
      messageId: msg.message_id,
    };
    usersMap.set(userId, userInfo);
  }
};
