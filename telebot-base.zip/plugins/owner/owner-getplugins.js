const fs = require('fs');
const path = require('path');
const { mess, ownerUsernames, ownerId } = require('../../settings');

module.exports = {
  cmd: ['gp'],
  tags: ['owner'],

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const username = msg.from?.username?.toLowerCase();
    const userId = msg.from?.id.toString();
    const isOwner = userId === ownerId || ownerUsernames.includes(username);

    if (!isOwner) {
      return bot.sendMessage(chatId, mess.owner, {
        reply_to_message_id: msg.message_id,
      });
    }

    const fileNameRaw = (args.join(' ') || '').trim();
    if (!fileNameRaw) {
      return bot.sendMessage(chatId, '📂 Nama file plugin-nya mana?\n\nContoh: `/gp main-menu`', {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown',
      });
    }

    const fileName = `${fileNameRaw}${fileNameRaw.endsWith('.js') ? '' : '.js'}`;
    const fullPath = path.join(__dirname, fileName);
    const availablePlugins = fs.readdirSync(__dirname)
      .filter(f => f.endsWith('.js'))
      .map(f => f.replace(/\.js$/, ''));

    if (!fs.existsSync(fullPath)) {
      const list = availablePlugins.map(p => `- ${p}`).join('\n');
      return bot.sendMessage(chatId, `❌ File *${fileName}* gak ketemu!\n\n📁 Daftar plugin:\n${list}`, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown',
      });
    }

    const content = fs.readFileSync(fullPath, 'utf8');
    const MAX_LENGTH = 4000;

    if (content.length > MAX_LENGTH) {
      const fileBuffer = Buffer.from(content, 'utf8');
      return bot.sendDocument(chatId, fileBuffer, {
        filename: fileName,
        caption: `📄 Isi file *${fileName}*`,
        parse_mode: 'Markdown'
      });
    }

    // Escape karakter khusus Markdown agar tidak error parsing
    const escapeMd = (txt) => txt
      .replace(/[`*_[\]()~>#+=|{}.!-]/g, '\\$&');

    bot.sendMessage(chatId, `📄 Isi file *${fileName}*:\n\n\`\`\`js\n${escapeMd(content)}\n\`\`\``, {
      reply_to_message_id: msg.message_id,
      parse_mode: 'MarkdownV2',
    });
  }
};
