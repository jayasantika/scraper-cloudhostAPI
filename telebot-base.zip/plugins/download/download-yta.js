const fetch = require('node-fetch');
const ytSearch = require('yt-search');
const { fromBuffer } = require('file-type');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const fs = require('fs');
const { tmpdir } = require('os');
const path = require('path');
const { randomUUID } = require('crypto');
const { mess, api, apikey } = require('../../settings');

ffmpeg.setFfmpegPath(ffmpegPath);

function escapeMetadata(value) {
  return value.replace(/"/g, '\\"'); // escape kutip ganda
}

function convertToMp3(bufferInput, title = 'Audio', artist = 'Unknown') {
  return new Promise((resolve, reject) => {
    const inputPath = path.join(tmpdir(), `${randomUUID()}.input`);
    const outputPath = path.join(tmpdir(), `${randomUUID()}.mp3`);
    fs.writeFileSync(inputPath, bufferInput);

    const safeTitle = escapeMetadata(title);
    const safeArtist = escapeMetadata(artist);

    ffmpeg(inputPath)
      .audioCodec('libmp3lame')
      .format('mp3')
      .outputOptions([
        `-metadata`, `title=${safeTitle}`,
        `-metadata`, `artist=${safeArtist}`
      ])
      .on('error', err => {
        fs.unlinkSync(inputPath);
        reject(err);
      })
      .on('end', () => {
        const outputBuffer = fs.readFileSync(outputPath);
        fs.unlinkSync(inputPath);
        fs.unlinkSync(outputPath);
        resolve(outputBuffer);
      })
      .save(outputPath);
  });
}

module.exports = {
  cmd: ['ytmp3', 'yta'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const text = args.join(' ');

    if (!text) {
      return bot.sendMessage(chatId, `Contoh: /ytmp3 https://www.youtube.com/watch?v=Z28dtg_QmFw`, {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait || '⏳ Sedang mencari...', {
      reply_to_message_id: msg.message_id
    });

    try {
      // Cari video dengan yt-search
      const search = await ytSearch(text);
      const video = search.videos[0];
      if (!video) throw new Error('Video tidak ditemukan');

      const videoUrl = video.url;
      const title = video.title;
      const artist = video.author?.name || 'Unknown';

      // Ambil MP3 dari API
      const res = await fetch(`${api}/api/download/ytmp3?url=${encodeURIComponent(videoUrl)}&apikey=${apikey}`);
      const json = await res.json();
      if (!json.status || !json.result?.mp3) throw new Error('Gagal mengambil audio.');

      // Download dan cek jenis file
      const response = await fetch(json.result.mp3);
      let audioBuffer = await response.buffer();
      const fileType = await fromBuffer(audioBuffer);

      // Konversi jika perlu
      if (!fileType || fileType.mime !== 'audio/mpeg') {
        audioBuffer = await convertToMp3(audioBuffer, title, artist);
      }

      const fileName = `${title}.mp3`;

      await bot.sendAudio(chatId, audioBuffer, {
        title,
        performer: artist,
        reply_to_message_id: msg.message_id
      }, {
        filename: fileName,
        contentType: 'audio/mpeg'
      });

    } catch (err) {
      console.error('YTMP3 error:', err);
      bot.sendMessage(chatId, '❌ Gagal mengambil audio. Pastikan link atau judul valid.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
