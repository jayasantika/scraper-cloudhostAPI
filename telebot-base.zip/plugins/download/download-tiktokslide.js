const fetch = require('node-fetch');
const { buttonUrl, mess, api, apikey } = require('../../settings');

module.exports = {
  cmd: ['tiktokslide'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(" ").trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '📥 Input Link!\nContoh:\n/tiktokslide https://vt.tiktok.com/ZS2qsMU1W/', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/ttslide?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);
      const json = await response.json();

      const result = json?.result;
      if (!result || !Array.isArray(result.images)) {
        throw new Error('Data dari API tidak lengkap');
      }

      const { title, totalSlide, images, audio } = result;

      const caption = [
        `Deskripsi: ${title || '-'}`,
        `Total Slide: ${totalSlide || images.length}`
      ].join('\n');

      const mediaGroup = images.map((url, index) => ({
        type: 'photo',
        media: url,
        ...(index === 0 ? { caption } : {})
      }));

      await bot.sendMediaGroup(chatId, mediaGroup, {
        reply_to_message_id: msg.message_id
      });

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
            ...(audio?.[0] ? [[{ text: '🎧 Audio', url: audio[0] }]] : [])
          ]
        }
      };

      await bot.sendMessage(chatId, '📦 Slide berhasil dikirim.', {
        ...replyMarkup,
        reply_to_message_id: msg.message_id
      });

    } catch (error) {
      console.error('TikTokSlide Error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil slide. Pastikan link valid dan API aktif.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
