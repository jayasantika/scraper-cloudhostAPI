const search = require('yt-search');
const fetch = require('node-fetch');
const { mess, api, apikey } = require('../../settings');
const { fromBuffer } = require('file-type');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const fs = require('fs');
const { tmpdir } = require('os');
const path = require('path');
const { randomUUID } = require('crypto');

ffmpeg.setFfmpegPath(ffmpegPath);

const convertToMp3 = (inputBuffer) => {
  return new Promise((resolve, reject) => {
    const tmpInput = path.join(tmpdir(), `${randomUUID()}.webm`);
    const tmpOutput = path.join(tmpdir(), `${randomUUID()}.mp3`);

    fs.writeFileSync(tmpInput, inputBuffer);

    ffmpeg(tmpInput)
      .toFormat('mp3')
      .on('error', (err) => {
        fs.unlinkSync(tmpInput);
        reject(err);
      })
      .on('end', () => {
        const outputBuffer = fs.readFileSync(tmpOutput);
        fs.unlinkSync(tmpInput);
        fs.unlinkSync(tmpOutput);
        resolve(outputBuffer);
      })
      .save(tmpOutput);
  });
};

module.exports = {
  cmd: ['play', 'song', 'ds'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const text = args.join(' ');

    if (!text) {
      return bot.sendMessage(chatId, '❗ Masukkan judul atau link YouTube!', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const results = await search(text);
      const video = results.videos[0];

      if (!video) {
        return bot.sendMessage(chatId, '❌ Video tidak ditemukan.', {
          reply_to_message_id: msg.message_id
        });
      }

      if (video.seconds >= 3600) {
        return bot.sendMessage(chatId, '⏱️ Video lebih dari 1 jam tidak didukung.', {
          reply_to_message_id: msg.message_id
        });
      }

      const res = await fetch(`${api}/api/download/ytmp3?url=${video.url}&apikey=${apikey}`);
      const json = await res.json();
      if (!json.status || !json.result?.mp3) {
        throw new Error('Gagal mengambil data MP3.');
      }

      const { title, duration, source, mp3 } = json.result;
      const caption = [
        `🎵 *${title}*`,
        `⏱ Durasi: ${duration} detik`,
        `[📺 Tonton di YouTube](${source})`
      ].join('\n');

      let audioBuffer = await fetch(mp3).then(r => r.buffer());
      let fileInfo = await fromBuffer(audioBuffer);
      let ext = fileInfo?.ext || 'mp3';
      let mime = fileInfo?.mime || 'audio/mpeg';

      // Konversi jika bukan mp3
      if (ext !== 'mp3') {
        audioBuffer = await convertToMp3(audioBuffer);
        ext = 'mp3';
        mime = 'audio/mpeg';
      }

      const fileName = `${title}.${ext}`;
      const sizeMB = audioBuffer.length / 1024 / 1024;

      const commonOpts = {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown',
        caption
      };

      if (sizeMB <= 50) {
        await bot.sendAudio(chatId, audioBuffer, {
          ...commonOpts,
          title,
          performer: video.author.name
        }, {
          filename: fileName,
          contentType: mime
        });
      } else {
        await bot.sendDocument(chatId, audioBuffer, {
          ...commonOpts,
          filename: fileName,
          contentType: mime
        });
      }

    } catch (err) {
      console.error('Error:', err);
      bot.sendMessage(chatId, mess.eror || '❌ Terjadi kesalahan saat mengambil data.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
