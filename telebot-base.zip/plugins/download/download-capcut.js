const fetch = require('node-fetch');
const { mess, buttonUrl, api, apikey } = require('../../settings');

module.exports = {
  cmd: ['capcutdl'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(" ").trim();

    if (!inputText) {
      return bot.sendMessage(chatId, 'Input Link!\nContoh:\n/capcutdl https://www.capcut.com/template-detail/7273798219329441025...', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/capcut?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`API Error ${response.status}: ${errText}`);
      }

      const json = await response.json();
      if (!json.result || !json.result.video) {
        throw new Error('Result tidak valid atau tidak mengandung video');
      }

      const { video, thumbnail, id, title, short_title, owner } = json.result;
      const caption = `🆔 ID: ${id}\n🎬 Judul: ${title}\n🧾 Judul Pendek: ${short_title}\n👤 Pemilik: ${owner}`;

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }]
          ]
        }
      };

      const resVid = await fetch(video);
      if (!resVid.ok) throw new Error('Gagal download video dari URL');

      const MAX_SIZE_MB = 49;
      const contentLength = resVid.headers.get('content-length');
      const contentType = resVid.headers.get('content-type');

      if (contentLength && parseInt(contentLength) > MAX_SIZE_MB * 1024 * 1024) {
        const fallbackCaption = `⚠️ Ukuran video melebihi batas ${MAX_SIZE_MB}MB.\n\nKlik tombol di bawah untuk mendownload manual:`;

        const fallbackMarkup = {
          reply_markup: {
            inline_keyboard: [
              [{ text: '⬇️ Download Video', url: video }],
              [{ text: '🔗 Script Bot', url: buttonUrl }]
            ]
          }
        };

        return bot.sendMessage(chatId, fallbackCaption, {
          reply_to_message_id: msg.message_id,
          ...fallbackMarkup
        });
      }

      if (!contentType || !contentType.includes('video')) {
        throw new Error(`File yang diambil bukan video. Tipe: ${contentType}`);
      }

      const videoBuffer = await resVid.buffer();

      bot.sendVideo(chatId, videoBuffer, {
        caption,
        reply_to_message_id: msg.message_id,
        ...replyMarkup
      });

    } catch (error) {
      console.error('CapCutDL Error:', error.message);
      bot.sendMessage(chatId, '❌ Gagal mengambil data.\nCek link CapCut atau coba lagi nanti.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
