const fetch = require('node-fetch');
const { mess, api, apikey } = require('../../settings');
const crypto = require('crypto');

module.exports = {
  cmd: ['ytmp4', 'ytv'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const text = args.join(' ').trim();

    if (!text) {
      return bot.sendMessage(chatId, 'Contoh:\n/ytmp4 https://www.youtube.com/watch?v=Z28dtg_QmFw', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait || '⏳ Mengambil video...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/ytmp4?url=${encodeURIComponent(text)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);
      const json = await response.json();

      if (!json.status || !json.result?.mp4) {
        throw new Error('Gagal mengambil video.');
      }

      const videoUrl = json.result.mp4;
      const title = json.result.title || 'yt_video';

      const videoRes = await fetch(videoUrl);
      const videoBuffer = await videoRes.buffer();

      const safeTitle = title.replace(/[^\w\s-]/g, '').slice(0, 30).trim().replace(/\s+/g, '_');
      const fileName = `${safeTitle}_${crypto.randomUUID().slice(0, 8)}.mp4`;

      await bot.sendVideo(chatId, videoBuffer, {
        caption: `🎬 ${title}`,
        reply_to_message_id: msg.message_id
      }, {
        filename: fileName,
        contentType: 'video/mp4'
      });

    } catch (error) {
      console.error('YTMP4 error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil video. Pastikan URL valid atau coba lagi nanti.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
