const fetch = require('node-fetch');
const { buttonUrl, mess, api, apikey } = require('../../settings');

module.exports = {
  cmd: ['xnxxdown', 'xnxxdl'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(" ").trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input link!\nContoh:\n/xnxxdown https://www.xnxx.com/video-y3pklda/jav_short_secretary_satisfies_her_boss', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/xnxxdl?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`API Error ${response.status}: ${errText}`);
      }

      const json = await response.json();
      if (!json.result || !json.result.url?.[0]) {
        throw new Error('Result tidak valid atau tidak mengandung video');
      }

      const { title, keyword, quality, views, url } = json.result;

      const videoResponse = await fetch(url);
      const contentLength = parseInt(videoResponse.headers.get('content-length') || '0', 10);

      const caption = `🎬 Judul: ${title || '-'}\n${keyword || '-'}\n\n🎬 Kualitas: ${quality}\n🎬 Penonton: ${views}`;

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
          ],
        }
      };

      if (contentLength > 49 * 1024 * 1024) {
        return bot.sendMessage(chatId, `${caption}\n\n📎 Video terlalu besar\n👉 ${url}`, {
          ...replyMarkup,
          disable_web_page_preview: false,
          reply_to_message_id: msg.message_id
        });
      }

      const videoBuffer = await videoResponse.buffer();

      await bot.sendVideo(chatId, videoBuffer, {
        caption,
        ...replyMarkup,
        reply_to_message_id: msg.message_id
      });

    } catch (error) {
      console.error('XnxxDL Error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil video. Coba lagi dengan link lain atau cek API.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
