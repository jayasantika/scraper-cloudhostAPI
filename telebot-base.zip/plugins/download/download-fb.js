const fetch = require('node-fetch');

module.exports = {
  cmd: ['fbdl'],
  tags: ['download'],
  exec: async (bot, { msg, args, cmd }) => {
    const inputText = args.join(" ").trim();
    const chatId = msg.chat.id;
    const buttonUrl = require('../../settings').buttonUrl;
    const mess = require('../../settings').mess;
    const api = require('../../settings').api;
    const apikey = require('../../settings').apikey;

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Masukkan link Facebook!\nContoh:\n/fbdl https://www.facebook.com/watch/?v=1393572814172251', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/fbdown?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);
      const json = await response.json();

      if (!json.result || !json.result[0]?._url) {
        throw new Error('Link video tidak ditemukan di hasil API');
      }

      const data = json.result[0];
      const videoUrl = data._url;
      const resolution = data.resolution || 'Unknown Resolution';

      const videoRes = await fetch(videoUrl);
      const contentLength = parseInt(videoRes.headers.get('content-length') || '0', 10);

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
            [{ text: '🌐 Buka Video', url: videoUrl }],
          ],
        }
      };

      if (contentLength > 49 * 1024 * 1024) {
        return bot.sendMessage(chatId, `📹 Video terlalu besar untuk dikirim langsung.\n📺 Resolusi: ${resolution}\n👉 Link: ${videoUrl}`, {
          reply_to_message_id: msg.message_id,
          ...replyMarkup
        });
      }

      const videoBuffer = await videoRes.buffer();

      bot.sendVideo(chatId, videoBuffer, {
        caption: `📥 Facebook Video\n🎞️ Resolusi: ${resolution}`,
        reply_to_message_id: msg.message_id,
        ...replyMarkup
      });

    } catch (error) {
      console.error('FB Downloader Error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengunduh video Facebook. Coba lagi dengan link lain atau cek API.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
}
