const fetch = require('node-fetch');
const crypto = require('crypto');
const upload = require('../../lib/uploader'); // pastikan path sesuai
const { buttonUrl, mess, api, apikey } = require('../../settings');

module.exports = {
  cmd: ['tiktok'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(" ").trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input link!\nContoh:\n/tiktok https://vt.tiktok.com/ZSY8XguF2/', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait || '⏳ Sedang diproses...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/tiktok?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);
      if (!response.ok) throw new Error(`API Error ${response.status}`);

      const json = await response.json();
      if (!json.result || !json.result.video?.[0]) throw new Error('Hasil tidak valid');

      const { title, title_audio, video, audio } = json.result;
      const videoUrl = Array.isArray(video) ? video[0] : video;
      const audioUrl = Array.isArray(audio) ? audio[0] : audio;

      // Proses nama file aman
      const randomId = crypto.randomUUID().slice(0, 8);
      const safeTitle = (title || 'tiktok_video')
        .replace(/[^\w\s-]/g, '')
        .slice(0, 30)
        .trim()
        .replace(/\s+/g, '_');
      const baseFileName = `${safeTitle}_${randomId}`;

      // Upload audio dan buat tombol callback
      const audioRes = await fetch(audioUrl);
      const audioBuffer = await audioRes.buffer();
      const uploadedAudioUrl = await upload(audioBuffer, `${baseFileName}.mp3`);

      const caption = `🎬 Deskripsi: ${title || '-'}\n🎵 Audio: ${title_audio || '-'}`;

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
            [{ text: '🎧 Audio', callback_data: `tiktok_audio|${uploadedAudioUrl}` }],
          ]
        }
      };

      const videoRes = await fetch(videoUrl);
      const videoBuffer = await videoRes.buffer();
      const sizeMB = videoBuffer.length / 1024 / 1024;

      if (sizeMB > 49) {
        return bot.sendMessage(chatId, `${caption}\n\n📎 Video terlalu besar\n👉 ${videoUrl}`, {
          ...replyMarkup,
          disable_web_page_preview: false,
          reply_to_message_id: msg.message_id
        });
      }

      await bot.sendVideo(chatId, videoBuffer, {
        caption,
        reply_to_message_id: msg.message_id,
        ...replyMarkup
      }, {
        filename: `${baseFileName}.mp4`,
        contentType: 'video/mp4'
      });

    } catch (err) {
      console.error('TikTokDL Error:', err);
      bot.sendMessage(chatId, '❌ Gagal mengambil video.', {
        reply_to_message_id: msg.message_id
      });
    }
  },

  callback: async (bot, { query }) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const [_, audioLink] = query.data.split('|');

    await bot.answerCallbackQuery(query.id);

    if (!audioLink?.startsWith('http')) {
      return bot.sendMessage(chatId, '❌ Link audio tidak valid.', {
        reply_to_message_id: messageId
      });
    }

    try {
      await bot.sendMessage(chatId, '⏳ Mengirim audio...', {
        reply_to_message_id: messageId
      });

      const res = await fetch(audioLink);
      const audioBuffer = await res.buffer();

      await bot.sendAudio(chatId, audioBuffer, {
        reply_to_message_id: messageId
      }, {
        filename: audioLink.split('/').pop() || 'tiktok_audio.mp3',
        contentType: 'audio/mpeg'
      });

    } catch (err) {
      console.error('Audio fetch error:', err);
      bot.sendMessage(chatId, '❌ Gagal mengirim audio TikTok.', {
        reply_to_message_id: messageId
      });
    }
  }
};
