const yts = require('yt-search');
const { mess } = require('../../settings');
const delay = ms => new Promise(res => setTimeout(res, ms));

module.exports = {
  cmd: ['yts', 'ytsearch'],
  tags: ['download'],

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const text = args.join(' ').trim();

    if (!text) {
      return bot.sendMessage(chatId, '🔍 Masukkan judul yang ingin dicari!\nContoh: /yts lathi');
    }

    try {
      await bot.sendMessage(chatId, mess.wait, {
        reply_to_message_id: msg.message_id
      });

      const results = await yts(text);
      const entries = results.all.map((v, i) => {
        if (v.type === 'video') {
          return `${i + 1}. ${v.title}\n${v.url}\nDurasi: ${v.timestamp}\nUpload: ${v.ago}\nViews: ${v.views}`;
        } else if (v.type === 'channel') {
          return `${i + 1}. ${v.name}\n${v.url}\nSubscriber: ${v.subCountLabel}\nVideo: ${v.videoCount}`;
        }
        return null;
      }).filter(Boolean);

      if (entries.length === 0) {
        return bot.sendMessage(chatId, '❌ Tidak ada hasil ditemukan.');
      }

      // Pisah berdasarkan panjang pesan maksimum
      const maxLength = 4000;
      const allText = entries.join('\n\n------------------\n\n');
      const parts = [];
      for (let i = 0; i < allText.length; i += maxLength) {
        parts.push(allText.slice(i, i + maxLength));
      }

      // Kirim pesan pertama dengan preview link aktif
      const previewLink = results.all[0]?.url || 'https://youtube.com';
      await bot.sendMessage(chatId, `${parts[0]}\n\n${previewLink}`, {
        disable_web_page_preview: false
      });

      // Sisanya tanpa preview link
      for (let i = 1; i < parts.length; i++) {
        await delay(1500); // jeda 1.5 detik
        await bot.sendMessage(chatId, parts[i], {
          disable_web_page_preview: true
        });
      }

    } catch (err) {
      console.error('YTS Error:', err);
      bot.sendMessage(chatId, '❌ Terjadi kesalahan saat pencarian.');
    }
  }
};
