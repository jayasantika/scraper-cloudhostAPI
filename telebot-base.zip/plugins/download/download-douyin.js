const fetch = require('node-fetch');
const { buttonUrl, mess, api, apikey } = require('../../settings');

module.exports = {
  cmd: ['douyin'],
  tags: ['download'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(" ").trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input link!\nContoh:\n/douyin https://v.douyin.com/ikq8axJ/', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, {
      reply_to_message_id: msg.message_id
    });

    try {
      const apiUrl = `${api}/api/download/douyin?url=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`API Error ${response.status}: ${errText}`);
      }

      const json = await response.json();
      if (!json.result || !json.result.video?.[0]) {
        throw new Error('Result tidak valid atau tidak mengandung video');
      }

      const { title, title_audio, video, audio } = json.result;
      const videoUrl = Array.isArray(video) ? video[0] : video;
      const audioUrl = Array.isArray(audio) ? audio[0] : audio;

      const videoResponse = await fetch(videoUrl);
      const contentLength = parseInt(videoResponse.headers.get('content-length') || '0', 10);

      const caption = `🎬 Deskripsi: ${title || '-'}\n🎵 Audio: ${title_audio || '-'}`;
      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
            [{ text: '🎧 Audio', url: audioUrl }],
          ],
        }
      };

      if (contentLength > 49 * 1024 * 1024) {
        return bot.sendMessage(chatId, `${caption}\n\n📎 Video terlalu besar\n👉 ${videoUrl}`, {
          ...replyMarkup,
          disable_web_page_preview: false,
          reply_to_message_id: msg.message_id
        });
      }

      const videoBuffer = await videoResponse.buffer();

      await bot.sendVideo(chatId, videoBuffer, {
        caption,
        ...replyMarkup,
        reply_to_message_id: msg.message_id
      });

    } catch (error) {
      console.error('DouyinDL Error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil video. Coba lagi dengan link lain atau cek API.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
