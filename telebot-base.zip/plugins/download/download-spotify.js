const fetch = require('node-fetch');
const uploader = require('../../lib/uploader');
const { mess, api, apikey } = require('../../settings');

// Penyimpanan metadata sementara (key: shortlink → { artist, title })
const spotifyMap = {};

module.exports = {
  cmd: ['spotify'],
  tags: ['download'],
  callbackPrefix: 'spotify_playtop',

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const text = args.join(" ").trim();

    if (!text) {
      return bot.sendMessage(chatId, `🚩 Masukkan link Spotify atau judul lagu!`, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown'
      });
    }

    await bot.sendMessage(chatId, mess.wait || '⏳ Sedang diproses...', {
      reply_to_message_id: msg.message_id,
      parse_mode: 'Markdown'
    });

    if (/^https:\/\/open\.spotify\.com/i.test(text)) {
      try {
        const res = await fetch(`${api}/api/download/spotify?url=${encodeURIComponent(text)}&apikey=${apikey}`);
        const json = await res.json();
        const data = json.result?.data;
        if (!data?.url) throw new Error('Gagal mengambil lagu.');

        const { title, url, artist } = data;
        const artistName = artist?.name || 'Unknown';

        const audioBuffer = await fetch(url).then(r => r.buffer());

        await bot.sendAudio(chatId, audioBuffer, {
          performer: artistName,
          title,
          reply_to_message_id: msg.message_id
        }, {
          filename: `${artistName} - ${title}.mp3`,
          contentType: 'audio/mpeg'
        });

      } catch (err) {
        console.error('Spotify URL error:', err);
        return bot.sendMessage(chatId, '❌ Gagal mengunduh lagu dari URL Spotify.', {
          reply_to_message_id: msg.message_id
        });
      }

    } else {
      try {
        const res = await fetch(`${api}/api/search/spotify?query=${encodeURIComponent(text)}&apikey=${apikey}`);
        const json = await res.json();
        const results = json.result?.data || [];
        if (!results.length) throw new Error('Tidak ada hasil.');

        const top = results[0];
        const dlRes = await fetch(`${api}/api/download/spotify?url=${encodeURIComponent(top.url)}&apikey=${apikey}`);
        const dlJson = await dlRes.json();
        const song = dlJson.result?.data;
        if (!song?.url) throw new Error('Gagal ambil lagu.');

        const { title, url, artist } = song;
        const artistName = artist?.name || 'Unknown';
        const audioBuffer = await fetch(url).then(r => r.buffer());

        const shortUrl = await uploader(audioBuffer, `${artistName} - ${title}.mp3`);
        spotifyMap[shortUrl] = { title, artist: artistName }; // simpan metadata

        let listText = `🔍 *Hasil pencarian untuk:* _${text}_\n\n`;
        for (let i = 0; i < results.length; i++) {
          const r = results[i];
          listText += `*${i + 1}.* ${r.title}\n`;
          listText += `⏱ Durasi: ${r.duration}\n`;
          listText += `⭐ Popularitas: ${r.popularity}\n`;
          listText += `[🔗 Link](${r.url})\n\n`;
        }

        await bot.sendMessage(chatId, listText, {
          reply_to_message_id: msg.message_id,
          parse_mode: 'Markdown',
          disable_web_page_preview: true,
          reply_markup: {
            inline_keyboard: [[
              { text: '🎵 Putar lagu teratas', callback_data: `spotify_playtop|${encodeURIComponent(shortUrl)}` }
            ]]
          }
        });

      } catch (err) {
        console.error('Spotify search error:', err);
        bot.sendMessage(chatId, `❌ Gagal mencari lagu.`, {
          reply_to_message_id: msg.message_id
        });
      }
    }
  },

  callback: async (bot, { query }) => {
    const [_, fileUrlEncoded] = query.data.split('|');
    const fileUrl = decodeURIComponent(fileUrlEncoded);
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    await bot.answerCallbackQuery(query.id);
    await bot.sendMessage(chatId, '⏳ Memuat lagu teratas...', {
      reply_to_message_id: messageId
    });

    try {
      const audioRes = await fetch(fileUrl);
      const buffer = await audioRes.buffer();

      const meta = spotifyMap[fileUrl] || { title: 'Unknown', artist: 'Unknown' };

      await bot.sendAudio(chatId, buffer, {
        performer: meta.artist,
        title: meta.title,
        reply_to_message_id: messageId
      }, {
        filename: `${meta.artist} - ${meta.title}.mp3`,
        contentType: 'audio/mpeg'
      });

    } catch (err) {
      console.error('Spotify callback error:', err);
      bot.sendMessage(chatId, '❌ Gagal mengunduh ulang lagu.', {
        reply_to_message_id: messageId
      });
    }
  }
};
