const fetch = require('node-fetch');

module.exports = {
  cmd: ['bard'],
  tags: ['openai'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(' ').trim();
    const buttonUrl = require('../../settings').buttonUrl;
    const mess = require('../../settings').mess;
    const api = require('../../settings').api;
    const apikey = require('../../settings').apikey;

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input query!\nContoh:\n/bard apa itu AI?', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });

    try {
      const apiUrl = `${api}/api/search/bard-ai?text=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(apiUrl);
      const json = await response.json();

      if (!json.message) throw new Error('Response kosong atau tidak sesuai format.');

      const fullMessage = json.message;

      const splitMessage = (text, maxLength = 4000) => {
        const parts = [];
        while (text.length > 0) {
          parts.push(text.slice(0, maxLength));
          text = text.slice(maxLength);
        }
        return parts;
      };

      const messages = splitMessage(fullMessage);

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }]
          ]
        }
      };

      for (let i = 0; i < messages.length; i++) {
        await bot.sendMessage(chatId, messages[i], {
          reply_to_message_id: msg.message_id,
          ...replyMarkup
        });
      }

    } catch (error) {
      console.error('Bard Error:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil jawaban dari Bard.\nSilakan coba lagi nanti.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};