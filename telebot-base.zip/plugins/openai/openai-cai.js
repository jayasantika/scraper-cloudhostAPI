const fetch = require('node-fetch');
const { api, apikey, mess } = require('../../settings');

global.charAISession = {}; // Penyimpanan sesi karakter AI per user

module.exports = {
  cmd: ['caistart'],
  tags: ['openai'],
  callbackPrefix: 'cai_stop',

  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const character = args.join(' ').trim();

    if (!character) {
      return bot.sendMessage(chatId, `❗ Masukkan nama karakter.\n\nContoh:\n/caistart Kirito`, {
        reply_to_message_id: msg.message_id
      });
    }

    global.charAISession[userId] = {
      character,
      history: []
    };

    await bot.sendMessage(chatId, `🧠 Sesi dimulai dengan karakter *${character}*.\nSemua pesan kamu akan dijawab oleh karakter ini.\n\nTekan tombol di bawah untuk mengakhiri sesi.`, {
      reply_to_message_id: msg.message_id,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [[{ text: '🛑 Hentikan Sesi', callback_data: 'cai_stop' }]]
      }
    });
  },

  callback: async (bot, { query }) => {
    const userId = query.from.id;
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;

    delete global.charAISession[userId];

    await bot.editMessageText('✅ Sesi karakter AI telah dihentikan.', {
      chat_id: chatId,
      message_id: messageId
    });

    await bot.answerCallbackQuery(query.id, {
      text: 'Sesi dihentikan.',
      show_alert: true
    });
  },

  // Hook semua pesan user
  onMessage: async (msg, bot) => {
    const userId = msg.from?.id;
    const chatId = msg.chat?.id;
    const text = msg.text?.trim();

    if (!text || !global.charAISession[userId]) return;
    if (/^[\/#!.\-\\]/.test(text)) return; // skip command

    const session = global.charAISession[userId];
    const { character, history } = session;

    try {
      await bot.sendChatAction(chatId, 'typing');

      const url = `${api}/api/search/c-ai?prompt=${encodeURIComponent(text)}&char=${encodeURIComponent(character)}&apikey=${apikey}`;
      const res = await fetch(url);
      const json = await res.json();

      if (!json.message) throw new Error('Respon kosong');

      const responseText = json.message;

      // Simpan riwayat chat
      session.history.push({ role: 'user', content: text });
      session.history.push({ role: 'assistant', content: responseText });

      await bot.sendMessage(chatId, `🧠 *${character} berkata:*\n\n${responseText}`, {
        reply_to_message_id: msg.message_id,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[{ text: '🛑 Hentikan Sesi', callback_data: 'cai_stop' }]]
        }
      });

    } catch (e) {
      console.error('C-AI Error:', e);
      await bot.sendMessage(chatId, '❌ Gagal mendapatkan jawaban dari karakter AI.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
