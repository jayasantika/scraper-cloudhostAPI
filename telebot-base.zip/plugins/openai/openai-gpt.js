const fetch = require('node-fetch');
const { mess, api, apikey, buttonUrl } = require('../../settings');

module.exports = {
  cmd: ['ai'],
  tags: ['openai'],
  exec: async (bot, { msg, args }) => {
    const chatId = msg.chat.id;
    const inputText = args.join(' ').trim();

    if (!inputText) {
      return bot.sendMessage(chatId, '❗ Input query!\nContoh:\n/ai siapa itu elon musk?', {
        reply_to_message_id: msg.message_id
      });
    }

    bot.sendMessage(chatId, mess.wait, { reply_to_message_id: msg.message_id });

    try {
      const url = `${api}/api/search/openai-chat?text=${encodeURIComponent(inputText)}&apikey=${apikey}`;
      const response = await fetch(url);
      const data = await response.json();

      const replyText = data.message || '❌ Tidak ada respons dari AI.';

      const splitMessage = (text, maxLength = 4000) => {
        const parts = [];
        while (text.length > 0) {
          parts.push(text.slice(0, maxLength));
          text = text.slice(maxLength);
        }
        return parts;
      };

      const messages = splitMessage(replyText);

      const replyMarkup = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔗 Script Bot', url: buttonUrl }],
          ],
        },
      };

      for (let i = 0; i < messages.length; i++) {
        await bot.sendMessage(chatId, messages[i], {
          reply_to_message_id: msg.message_id,
          ...replyMarkup,
        });
      }

    } catch (err) {
      console.error('Error /ai:', err);
      bot.sendMessage(chatId, '❌ Gagal mengambil jawaban dari OpenAI.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
