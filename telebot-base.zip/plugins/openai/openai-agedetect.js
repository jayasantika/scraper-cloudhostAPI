const fetch = require('node-fetch');
const uploader = require('../../lib/uploader');
const { api, apikey, mess } = require('../../settings');

module.exports = {
  cmd: ['age', 'agedetect', 'agedetector'],
  tags: ['openai'],

  exec: async (bot, { msg }) => {
    const chatId = msg.chat.id;

    // Harus reply ke gambar
    const q = msg.reply_to_message;
    const mime = q?.photo ? 'image/jpeg' : '';

    if (!q || !mime) {
      return bot.sendMessage(chatId, '❗ Balas gambar dengan perintah ini.', {
        reply_to_message_id: msg.message_id
      });
    }

    await bot.sendMessage(chatId, mess.wait || '⏳ Mendeteksi usia wajah...', {
      reply_to_message_id: msg.message_id
    });

    try {
      const fileId = q.photo[q.photo.length - 1].file_id;
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const buffer = await fetch(fileUrl).then(r => r.buffer());

      const uploadedUrl = await uploader(buffer, `face_${Date.now()}.jpg`);

      const res = await fetch(`${api}/api/search/agedetect?url=${uploadedUrl}&apikey=${apikey}`);
      const json = await res.json();

      if (!json.result) {
        throw new Error('Tidak bisa membaca wajah.');
      }

      const result = json.result;
      const caption = [
        `*乂 A G E   D E T E C T I O N*`,
        ``,
        `◦ *Score:* ${result.score}`,
        `◦ *Age:* ${result.age}`,
        `◦ *Gender:* ${result.gender}`,
        `◦ *Expression:* ${result.expression}`,
        `◦ *Face Shape:* ${result.faceShape}`,
      ].join('\n');

      await bot.sendPhoto(chatId, buffer, {
        caption,
        reply_to_message_id: msg.message_id,
        parse_mode: "Markdown",
      }, {
        filename: `agedetect.jpg`,
        contentType: 'image/jpeg'
      });

    } catch (err) {
      console.error('Age Detect Error:', err);
      bot.sendMessage(chatId, '❌ Gagal mendeteksi wajah.', {
        reply_to_message_id: msg.message_id
      });
    }
  }
};
