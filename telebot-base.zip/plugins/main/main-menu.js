const { imageUrl, prefix } = require('../../settings');
const Start = new Date();

function getDayName(dayIndex) {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[dayIndex];
}

function formatUptime() {
  const now = new Date();
  const uptimeMilliseconds = now - Start;
  const uptimeSeconds = Math.floor(uptimeMilliseconds / 1000);
  const uptimeMinutes = Math.floor(uptimeSeconds / 60);
  const uptimeHours = Math.floor(uptimeMinutes / 60);

  return { uptimeHours, uptimeMinutes, uptimeSeconds, now };
}

module.exports = {
  cmd: ['menu'],
  tags: ['info', 'main'],

  exec: async (bot, { msg, loadedPlugins }) => {
    const chatId = msg.chat.id;
    const { uptimeHours, uptimeMinutes, uptimeSeconds, now } = formatUptime();
    const username = msg.from.username || msg.from.first_name || 'User';

    const caption = [
      `Hi ${username}`,
      `I am an automated system (Telegram Bot) to assist you.`,
      '',
      `┌  ◦ Uptime: ${uptimeHours}h ${uptimeMinutes % 60}m ${uptimeSeconds % 60}s`,
      `│  ◦ Library: node-telegram-bot-api`,
      `│  ◦ Hari: ${getDayName(now.getDay())}`,
      `│  ◦ Waktu: ${now.toLocaleTimeString()}`,
      `│  ◦ Tanggal: ${now.toLocaleDateString()}`,
      `│  ◦ Version: 0.0.1`,
      '└',
      '',
      'Pilih kategori menu yang tersedia:'
    ].join('\n');

    const categories = [...new Set(loadedPlugins.map(p => p.tags?.[0] || 'other'))];
    const inline_keyboard = categories.map(tag => [
      { text: tag.toUpperCase(), callback_data: `menu:${tag}` }
    ]);

    await bot.sendPhoto(chatId, imageUrl, {
      caption,
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard }
    });
  },

  callback: async (bot, { query, command }) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;
    const category = data.split(':')[1];

    const { uptimeHours, uptimeMinutes, uptimeSeconds, now } = formatUptime();

    if (category === 'back') {
      const caption = [
        `Hi ${query.from.username || query.from.first_name}`,
        `I am an automated system (Telegram Bot) to assist you.`,
        '',
        `┌  ◦ Uptime: ${uptimeHours}h ${uptimeMinutes % 60}m ${uptimeSeconds % 60}s`,
        `│  ◦ Library: node-telegram-bot-api`,
        `│  ◦ Hari: ${getDayName(now.getDay())}`,
        `│  ◦ Waktu: ${now.toLocaleTimeString()}`,
        `│  ◦ Tanggal: ${now.toLocaleDateString()}`,
        `│  ◦ Version: 0.0.1`,
        '└',
        '',
        'Pilih kategori menu yang tersedia:'
      ].join('\n');

      const categories = [...new Set(commandPlugins.map(p => p.tags?.[0] || 'other'))];
      const inline_keyboard = categories.map(tag => [
        { text: tag.toUpperCase(), callback_data: `menu:${tag}` }
      ]);

      return bot.editMessageCaption(caption, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard }
      });
    }

    // tampilkan isi kategori
    const pluginsByCategory = commandPlugins.filter(p => (p.tags?.[0] || 'other') === category);
    let responseText = `◦ Kategori: ${category.toUpperCase()}\n\n`;
    for (const plugin of pluginsByCategory) {
      const commands = plugin.cmd || plugin.commands || [];
      for (const cmd of commands) {
        responseText += `◦ ${prefix}${cmd}\n`;
      }
    }

    await bot.editMessageCaption(responseText, {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [[{ text: '🔙 KEMBALI', callback_data: 'menu:back' }]]
      }
    });

    await bot.answerCallbackQuery(query.id);
  }
};
