module.exports = {
  cmd: ['start'],
  tags: ['main'],
  exec: async (bot, { msg }) => {
    const buttonUrl = require('../../settings').buttonUrl;
    const ownerUsernames = require('../../settings').ownerUsernames;

    const user = msg.from;
    const chatId = msg.chat.id;

    const caption = `Hi ${user.first_name}! Welcome to Novanira SmartBotz. I'm a Telegram bot based on node-telegram-api, ready to help you 😄\n\nKetik /menu untuk melihat semua daftar menu.`;

    const replyMarkup = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔗 Script Bot', url: buttonUrl }],
          [{ text: '💬 My Owner', url: 'https://t.me/' + ownerUsernames }],
        ],
      },
    };

    await bot.sendMessage(chatId, caption, {
      reply_to_message_id: msg.message_id,
      ...replyMarkup
    });
  }
};
