module.exports = {
  tags: ['main'],
  cmd: ['cekid'],
  exec: async function (bot, { msg }) {
    const user = msg.from;
    const chat = msg.chat;

    const chatId = chat.id.toString();
    const userId = user.id.toString();

    const text = [
      `🆔 Chat ID : ${chatId}`,
      `👤 Your ID : ${userId}`,
      `💬 Type    : ${chat.type}`
    ].join('\n');

    await bot.sendMessage(chat.id, text, {
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: '📋 Chat ID (Popup)', callback_data: `copy_chat_${chatId}` },
            { text: '📋 User ID (Popup)', callback_data: `copy_user_${userId}` }
          ],
          [
            {
              text: '🔗 Copy Chat ID',
              url: `https://t.me/share/url?url=${encodeURIComponent(chatId)}&text=Copy%20Chat%20ID`
            },
            {
              text: '🔗 Copy User ID',
              url: `https://t.me/share/url?url=${encodeURIComponent(userId)}&text=Copy%20User%20ID`
            }
          ]
        ]
      }
    });
  },

  register: (bot) => {
    bot.on('callback_query', async (query) => {
      const data = query.data || '';
      if (data.startsWith('copy_chat_') || data.startsWith('copy_user_')) {
        const id = data.split('_').pop();

        await bot.answerCallbackQuery(query.id, {
          text: `ID: ${id}`,
          show_alert: true
        });
      }
    });
  }
};
