/*
Created By Lann Telegram Bot Plugins
Register Your Apikey in https://api.betabotz.eu.org
Replace Your Key with the apikey that you get in your profile.
*/

module.exports = {
  ownerUsernames: ["originalmallard_989881"],//Your Username
  ownerNumber: "6282339922441",//Your Number 
  ownerId: "5784544985",
  prefix: '/',
  telegramBotToken: "7245241053:AAGqV1zcGZ1-tGCfcxjYBOMhdg1_kjWdjhA",//Your Bot Tokens
  imageUrl: "https://files.catbox.moe/kjy9t2.jpg",//Thumbnail Url
  buttonUrl: "https://github.com/ERLANRAHMAT/telebot",//Script Url
  api: "https://api.betabotz.eu.org",
  apikey: "Fruatre-Btz",//Change Your Apikey
  rateLimitDefault: 5,
  mess: {
    eror: "Internal Server Error 😵",
    owner: "Sorry, this command can only be accessed by the owner!",
    group: "Sorry, this command can only be used within a group!",
    wait: "Your request is being processed...",
  },
};
